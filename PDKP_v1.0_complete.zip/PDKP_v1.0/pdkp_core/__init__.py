"""
PDKP v1.0 - Process-Based Modeling of Microplastic-Associated Additive Dynamics
================================================================================
A mechanistic framework for polymer degradation, additive partitioning,
and soil transport in agricultural soils.

Modules:
  - polymer_degradation: Module I (Polymer Degradation)
  - additive_partitioning: Module II (Additive Partitioning)  
  - soil_transport: Module III (Soil Transport)
  - sensitivity_analysis: Sobol and Morris sensitivity analysis
  - monte_carlo: Latin Hypercube Sampling uncertainty propagation
  - validation: Model validation metrics and benchmarking
  - scenario_projections: Future scenario modeling (2025-2050)
  - error_analysis: Error documentation and verification protocols
  - extensions: Future model extensions (pH, hysteresis, UV attenuation, etc.)

Authors: Marcos Fernandes de Oliveira et al.
License: MIT
Repository: https://github.com/65marcos/soil-microplastics
"""

__version__ = "1.0.0"
__author__ = "Marcos Fernandes de Oliveira"
__license__ = "MIT"

from .polymer_degradation import PolymerDegradation
from .additive_partitioning import AdditivePartitioning
from .soil_transport import SoilTransport
from .sensitivity_analysis import SensitivityAnalysis
from .monte_carlo import MonteCarloPropagation
from .validation import ValidationMetrics
from .scenario_projections import ScenarioProjections
from .error_analysis import ErrorDocumentation
from .extensions import ModelExtensions

__all__ = [
    'PolymerDegradation',
    'AdditivePartitioning', 
    'SoilTransport',
    'SensitivityAnalysis',
    'MonteCarloPropagation',
    'ValidationMetrics',
    'ScenarioProjections',
    'ErrorDocumentation',
    'ModelExtensions'
]
