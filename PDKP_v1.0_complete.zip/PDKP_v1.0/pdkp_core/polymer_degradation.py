"""
Module I: Polymer Degradation
==============================
Tracks temporal evolution of polymer molecular weight, crystallinity,
and surface area as functions of environmental stressors.

Equations implemented:
  Eq. 1: D(t) = [M_n(0) - M_n(t)] / M_n(0)
  Eq. 2: dM_n/dt = -k_deg * M_n * f_UV * f_T * f_moist * f_mech
  Eq. 3: f_UV = (I_UV / I_ref)^alpha_UV
  Eq. 4: f_T = exp[(E_a/R)(1/T_ref - 1/T)]
  Eq. 5: f_moist = 1 + beta_moist * (theta - theta_ref)
  Eq. 6: f_mech = 1 + gamma_mech * sigma_soil

SM S2.1: Full derivations of environmental modification factors
SM S3.2: Meta-analysis of lambda parameter from 47 weathering studies
SM S4.3: WLF parameter sensitivity
"""

import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import minimize_scalar
from dataclasses import dataclass
from typing import Dict, Tuple, Optional, Callable
import json

# Physical constants
R_GAS = 8.314  # J/(mol*K)
I_REF = 550.0  # W/m^2, global solar irradiance at 45°N summer noon
T_REF = 298.15  # K, 25°C
THETA_REF = 0.20  # m^3/m^3, typical agricultural soil
SIGMA_REF = 100e3  # Pa, reference tillage stress (100 kPa)


@dataclass
class PolymerParams:
    """Polymer-specific degradation parameters (Table 1, main text)"""
    name: str
    k_deg: float          # day^-1, intrinsic degradation rate
    E_a: float            # kJ/mol, activation energy
    alpha_UV: float       # UV scaling exponent
    beta_moist: float     # moisture sensitivity
    gamma_mech: float     # mechanical stress sensitivity
    delta: float          # degradation-dependence exponent for release
    M_n0: float           # g/mol, initial number-average molecular weight
    crystallinity0: float # %, initial crystallinity
    T_g: float = None     # K, glass transition temperature (for WLF)
    C1_wlf: float = 17.5  # WLF parameter C1
    C2_wlf: float = 51.6  # WLF parameter C2 (K)


# Polymer database (Table 1)
POLYMER_DATABASE = {
    'PE': PolymerParams(
        name='PE', k_deg=2.1e-5, E_a=42.0, alpha_UV=0.85,
        beta_moist=0.12, gamma_mech=0.08, delta=1.2,
        M_n0=85000, crystallinity0=45.0,
        T_g=195, C1_wlf=17.5, C2_wlf=51.6
    ),
    'PP': PolymerParams(
        name='PP', k_deg=3.8e-5, E_a=38.0, alpha_UV=0.72,
        beta_moist=0.15, gamma_mech=0.06, delta=1.5,
        M_n0=220000, crystallinity0=35.0,
        T_g=260, C1_wlf=16.0, C2_wlf=48.0
    ),
    'PET': PolymerParams(
        name='PET', k_deg=2.5e-5, E_a=55.0, alpha_UV=0.60,
        beta_moist=0.10, gamma_mech=0.04, delta=1.0,
        M_n0=45000, crystallinity0=30.0,
        T_g=343, C1_wlf=15.0, C2_wlf=42.0
    ),
    'PLA': PolymerParams(
        name='PLA', k_deg=8.2e-4, E_a=35.0, alpha_UV=0.90,
        beta_moist=0.20, gamma_mech=0.10, delta=2.0,
        M_n0=120000, crystallinity0=15.0,
        T_g=328, C1_wlf=18.0, C2_wlf=55.0
    ),
    'PBAT': PolymerParams(
        name='PBAT', k_deg=9.1e-4, E_a=32.0, alpha_UV=0.88,
        beta_moist=0.22, gamma_mech=0.12, delta=2.0,
        M_n0=95000, crystallinity0=12.0,
        T_g=315, C1_wlf=17.0, C2_wlf=50.0
    ),
}


class PolymerDegradation:
    """
    Module I: Polymer Degradation

    Computes temporal evolution of polymer properties under environmental
    stressors following Eqs. 1-6 of the main manuscript.
    """

    def __init__(self, polymer_type: str, params: Optional[PolymerParams] = None):
        """
        Initialize polymer degradation module.

        Parameters:
        -----------
        polymer_type : str
            One of 'PE', 'PP', 'PET', 'PLA', 'PBAT'
        params : PolymerParams, optional
            Custom parameters (uses database defaults if None)
        """
        if params is None:
            if polymer_type not in POLYMER_DATABASE:
                raise ValueError(f"Unknown polymer type: {polymer_type}")
            self.params = POLYMER_DATABASE[polymer_type]
        else:
            self.params = params
        self.polymer_type = polymer_type

    # ===== Environmental Modification Factors (Eq. 3-6) =====

    def f_UV(self, I_UV: float) -> float:
        """
        UV irradiance modification factor (Eq. 3).

        f_UV = (I_UV / I_ref)^alpha_UV

        Parameters:
        -----------
        I_UV : float
            UV irradiance (W/m^2)

        Returns:
        --------
        float : dimensionless UV factor
        """
        return (I_UV / I_REF) ** self.params.alpha_UV

    def f_T(self, T: float) -> float:
        """
        Temperature modification factor (Eq. 4, Arrhenius).

        f_T = exp[(E_a/R)(1/T_ref - 1/T)]

        Parameters:
        -----------
        T : float
            Soil temperature (K)

        Returns:
        --------
        float : dimensionless temperature factor
        """
        E_a_J = self.params.E_a * 1000  # convert kJ to J
        return np.exp((E_a_J / R_GAS) * (1.0 / T_REF - 1.0 / T))

    def f_moist(self, theta: float) -> float:
        """
        Soil moisture modification factor (Eq. 5).

        f_moist = 1 + beta_moist * (theta - theta_ref)

        Valid for theta in [0.05, 0.45] m^3/m^3.

        Parameters:
        -----------
        theta : float
            Volumetric water content (m^3/m^3)

        Returns:
        --------
        float : dimensionless moisture factor
        """
        theta_clipped = np.clip(theta, 0.05, 0.45)
        return 1.0 + self.params.beta_moist * (theta_clipped - THETA_REF)

    def f_mech(self, sigma_soil: float) -> float:
        """
        Mechanical stress modification factor (Eq. 6).

        f_mech = 1 + gamma_mech * sigma_soil

        Parameters:
        -----------
        sigma_soil : float
            Mechanical stress from tillage (Pa)
            Typical: 50-200 kPa for moldboard plow

        Returns:
        --------
        float : dimensionless mechanical factor
        """
        # Convert to kPa for gamma scaling
        sigma_kPa = sigma_soil / 1000.0
        return 1.0 + self.params.gamma_mech * sigma_kPa

    def compute_modification_factors(self, env: Dict) -> Dict[str, float]:
        """
        Compute all environmental modification factors.

        Parameters:
        -----------
        env : dict
            Dictionary with keys: 'I_UV', 'T', 'theta', 'sigma_soil'

        Returns:
        --------
        dict : {'f_UV': ..., 'f_T': ..., 'f_moist': ..., 'f_mech': ...}
        """
        return {
            'f_UV': self.f_UV(env['I_UV']),
            'f_T': self.f_T(env['T']),
            'f_moist': self.f_moist(env['theta']),
            'f_mech': self.f_mech(env['sigma_soil'])
        }

    # ===== Molecular Weight Evolution (Eq. 1-2) =====

    def dMn_dt(self, t: float, M_n: float, env: Dict) -> float:
        """
        ODE for molecular weight evolution (Eq. 2).

        dM_n/dt = -k_deg * M_n * f_UV * f_T * f_moist * f_mech

        Parameters:
        -----------
        t : float
            Time (days) - unused but required by solve_ivp
        M_n : float
            Current number-average molecular weight (g/mol)
        env : dict
            Environmental conditions

        Returns:
        --------
        float : dM_n/dt (g/mol/day)
        """
        factors = self.compute_modification_factors(env)
        f_total = factors['f_UV'] * factors['f_T'] * factors['f_moist'] * factors['f_mech']
        return -self.params.k_deg * M_n * f_total

    def solve_degradation(self, t_span: Tuple[float, float], 
                         env: Dict,
                         t_eval: Optional[np.ndarray] = None,
                         M_n0: Optional[float] = None) -> solve_ivp:
        """
        Solve molecular weight evolution over time.

        Parameters:
        -----------
        t_span : tuple
            (t_start, t_end) in days
        env : dict
            Environmental conditions (constant or time-varying)
        t_eval : array, optional
            Time points for output
        M_n0 : float, optional
            Initial molecular weight (uses params default if None)

        Returns:
        --------
        OdeResult : SciPy solve_ivp result
        """
        if M_n0 is None:
            M_n0 = self.params.M_n0

        # For time-varying environments, env should be a callable
        if callable(env):
            def ode(t, y):
                env_t = env(t)
                return self.dMn_dt(t, y[0], env_t)
        else:
            def ode(t, y):
                return self.dMn_dt(t, y[0], env)

        sol = solve_ivp(ode, t_span, [M_n0], method='BDF',
                       t_eval=t_eval, rtol=1e-6, atol=1e-9)
        return sol

    def degree_of_degradation(self, M_n: float) -> float:
        """
        Compute degree of polymer degradation D(t) (Eq. 1).

        D(t) = [M_n(0) - M_n(t)] / M_n(0)

        Parameters:
        -----------
        M_n : float or array
            Current molecular weight(s)

        Returns:
        --------
        float or array : D(t) in [0, 1]
        """
        return (self.params.M_n0 - M_n) / self.params.M_n0

    # ===== Crystallinity Evolution (Section 3.1, Fig. 2b) =====

    def compute_crystallinity(self, D: float) -> float:
        """
        Biphasic crystallinity model (Section 3.1, Fig. 2b).

        Phase 1 (0-12 months): amorphous regions degrade preferentially
          -> crystallinity decreases
        Phase 2 (12-60 months): crystalline regions become relatively enriched
          -> crystallinity increases

        Parameters:
        -----------
        D : float
            Degree of degradation [0, 1]

        Returns:
        --------
        float : crystallinity (%)
        """
        X_c0 = self.params.crystallinity0

        # Biphasic model parameters (calibrated from field data)
        # Phase 1: linear decrease to minimum at D ~ 0.15
        # Phase 2: linear increase as crystalline regions enrich
        D_transition = 0.15  # transition between phases
        X_c_min = X_c0 * 0.88  # minimum crystallinity (~12% reduction)

        if D <= D_transition:
            # Phase 1: amorphous degradation
            frac = D / D_transition
            X_c = X_c0 - frac * (X_c0 - X_c_min)
        else:
            # Phase 2: crystalline enrichment
            frac = (D - D_transition) / (0.5 - D_transition)  # normalize to D=0.5
            frac = min(frac, 1.0)
            X_c = X_c_min + frac * (X_c0 * 1.15 - X_c_min)  # increase above initial

        return X_c

    # ===== Surface Area-to-Volume Ratio (Fig. 2c) =====

    def compute_surface_area_ratio(self, D: float) -> float:
        """
        Surface area-to-volume ratio enhancement (Fig. 2c).

        As polymer degrades, porosity increases and surface area grows,
        enhancing additive accessibility to soil solution.

        Parameters:
        -----------
        D : float
            Degree of degradation [0, 1]

        Returns:
        --------
        float : SA/V ratio (mm^-1), relative to initial
        """
        # Empirical power-law from field data
        # SA/V increases with degradation due to surface roughening
        SA_V0 = {'PE': 0.12, 'PP': 0.08, 'PET': 0.18, 'PLA': 0.15, 'PBAT': 0.14}

        base = SA_V0.get(self.polymer_type, 0.12)
        enhancement = 1.0 + 2.5 * D + 1.5 * D**2  # non-linear enhancement

        return base * enhancement

    # ===== WLF Equation (SM S4.3, Eq. S4.4) =====

    def wlf_diffusion(self, T: float) -> float:
        """
        Williams-Landel-Ferry equation for temperature-dependent
        polymer diffusion coefficient (SM S4.3, Eq. S4.4).

        log(D_poly/D_g) = -C1*(T - T_g) / [C2 + (T - T_g)]

        Parameters:
        -----------
        T : float
            Temperature (K)

        Returns:
        --------
        float : D_poly / D_g (dimensionless ratio)
        """
        if self.params.T_g is None:
            return 1.0  # no WLF correction if T_g not defined

        T_g = self.params.T_g
        C1 = self.params.C1_wlf
        C2 = self.params.C2_wlf

        # Piecewise formulation with smooth Arrhenius crossover (E-003 correction)
        delta_buffer = 0.1  # K, smoothing buffer
        T_cross = T_g - C2

        if T >= T_cross + delta_buffer:
            # Above crossover: WLF applies
            log_ratio = -C1 * (T - T_g) / (C2 + (T - T_g))
            return 10 ** log_ratio
        elif T <= T_cross - delta_buffer:
            # Below crossover: Arrhenius behavior
            # Smooth crossover ensures continuity
            log_ratio_cross = -C1 * (T_cross - T_g) / (C2 + (T_cross - T_g))
            D_ratio_cross = 10 ** log_ratio_cross

            # Arrhenius continuation below T_cross
            E_a_wlf = 2.303 * R_GAS * C1 * C2  # effective activation energy
            return D_ratio_cross * np.exp(-E_a_wlf / R_GAS * (1/T - 1/T_cross))
        else:
            # Smooth interpolation in buffer zone
            T_mid = T_cross
            log_ratio_mid = -C1 * (T_mid - T_g) / (C2 + (T_mid - T_g))
            return 10 ** log_ratio_mid

    # ===== Lambda Parameter (SM S3.2) =====

    def compute_lambda(self, I_UV: float, T: float, theta: float) -> float:
        """
        Compute effective degradation enhancement factor lambda
        from meta-analysis of 47 weathering studies (SM S3.2).

        log(lambda) = beta_0 + beta_1*log(I_UV) + beta_2*T + beta_3*theta

        Parameters:
        -----------
        I_UV : float
            UV irradiance (W/m^2)
        T : float
            Temperature (°C)
        theta : float
            Volumetric water content (m^3/m^3)

        Returns:
        --------
        float : lambda enhancement factor
        """
        # Mixed-effects model coefficients (Table S3.1)
        beta_0 = -0.42
        beta_1 = 0.38
        beta_2 = 0.025
        beta_3 = 0.18

        log_lambda = beta_0 + beta_1 * np.log(I_UV) + beta_2 * T + beta_3 * theta
        return np.exp(log_lambda)

    # ===== Batch simulation for multiple time points =====

    def simulate(self, days: np.ndarray, env: Dict) -> Dict:
        """
        Run complete degradation simulation.

        Parameters:
        -----------
        days : array
            Time points (days)
        env : dict
            Environmental conditions

        Returns:
        --------
        dict : {
            'time': days,
            'M_n': molecular weights,
            'D': degradation degrees,
            'crystallinity': crystallinities,
            'SA_V': surface area ratios,
            'factors': modification factors
        }
        """
        t_span = (days[0], days[-1])
        sol = self.solve_degradation(t_span, env, t_eval=days)

        M_n = sol.y[0]
        D = self.degree_of_degradation(M_n)
        X_c = np.array([self.compute_crystallinity(d) for d in D])
        SA_V = np.array([self.compute_surface_area_ratio(d) for d in D])

        return {
            'time': days,
            'M_n': M_n,
            'D': D,
            'crystallinity': X_c,
            'SA_V': SA_V,
            'factors': self.compute_modification_factors(env)
        }
