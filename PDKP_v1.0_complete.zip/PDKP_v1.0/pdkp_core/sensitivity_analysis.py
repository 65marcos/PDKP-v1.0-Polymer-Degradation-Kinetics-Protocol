"""
Sensitivity Analysis Module
=============================
Variance-based Sobol sensitivity analysis and Morris screening
for global parameter sensitivity assessment.

Equations implemented:
  Eq. S4.1: First-order Sobol index S_i
  Eq. S4.2: Total-effect Sobol index S_Ti
  Eq. S4.3: Morris elementary effect EE_i

SM S4.1: Complete Sobol sensitivity analysis protocol
SM S4.3: WLF parameter sensitivity testing
"""

import numpy as np
from scipy.stats import qmc, spearmanr
from typing import Dict, List, Callable, Tuple, Optional
from dataclasses import dataclass
from concurrent.futures import ProcessPoolExecutor
import warnings


@dataclass
class SensitivityConfig:
    """Configuration for sensitivity analysis"""
    n_sobol: int = 10000      # Number of model evaluations for Sobol
    n_morris: int = 20        # Number of Morris trajectories
    n_bootstrap: int = 1000   # Bootstrap samples for CI
    n_cores: int = -1         # Number of parallel cores (-1 = all)


class SensitivityAnalysis:
    """
    Global sensitivity analysis using Sobol indices and Morris screening.

    Implements Saltelli sampling scheme for variance-based decomposition
    and Morris elementary effects for consistency checking.
    """

    def __init__(self, config: Optional[SensitivityConfig] = None):
        self.config = config if config is not None else SensitivityConfig()

    # ===== Sobol Sensitivity Analysis (SM S4.1) =====

    def saltelli_sampling(self, param_bounds: Dict[str, Tuple[float, float]],
                         N: int) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generate Saltelli sampling matrices for Sobol analysis.

        Creates two independent N x k matrices A and B, then constructs
        N*(k+2) total samples for first-order and total-effect indices.

        Parameters:
        -----------
        param_bounds : dict
            {param_name: (lower, upper)}
        N : int
            Base sample size (total evaluations = N*(k+2))

        Returns:
        --------
        tuple : (A, B) sampling matrices
        """
        k = len(param_bounds)
        param_names = list(param_bounds.keys())

        # Generate two independent LHS samples
        sampler_A = qmc.LatinHypercube(d=k, seed=42)
        sampler_B = qmc.LatinHypercube(d=k, seed=43)

        A_unit = sampler_A.random(n=N)
        B_unit = sampler_B.random(n=N)

        # Scale to parameter bounds
        A = np.zeros((N, k))
        B = np.zeros((N, k))

        for i, name in enumerate(param_names):
            low, high = param_bounds[name]
            A[:, i] = low + A_unit[:, i] * (high - low)
            B[:, i] = low + B_unit[:, i] * (high - low)

        return A, B, param_names

    def compute_sobol_indices(self, model: Callable,
                             param_bounds: Dict[str, Tuple[float, float]],
                             N: Optional[int] = None,
                             output_index: int = 0) -> Dict:
        """
        Compute first-order (S_i) and total-effect (S_Ti) Sobol indices.

        Uses Saltelli scheme: N*(k+2) model evaluations.

        Parameters:
        -----------
        model : callable
            Function y = model(params_dict) returning array of outputs
        param_bounds : dict
            {param_name: (lower, upper)}
        N : int, optional
            Base sample size (uses config default if None)
        output_index : int
            Index of output variable to analyze

        Returns:
        --------
        dict : {
            'S_i': first-order indices,
            'S_Ti': total-effect indices,
            'S_interaction': interaction indices (S_Ti - S_i),
            'param_names': parameter names,
            'V_Y': total output variance
        }
        """
        if N is None:
            N = self.config.n_sobol

        A, B, param_names = self.saltelli_sampling(param_bounds, N)
        k = len(param_names)

        # Evaluate model at A and B
        Y_A = np.array([model(dict(zip(param_names, a)))[output_index] 
                        for a in A])
        Y_B = np.array([model(dict(zip(param_names, b)))[output_index] 
                        for b in B])

        # Total variance
        V_Y = np.var(np.concatenate([Y_A, Y_B]))

        S_i = np.zeros(k)
        S_Ti = np.zeros(k)

        # Compute indices for each parameter
        for i in range(k):
            # Create A_B^i (replace i-th column of A with B)
            A_B_i = A.copy()
            A_B_i[:, i] = B[:, i]

            Y_AB = np.array([model(dict(zip(param_names, ab)))[output_index] 
                             for ab in A_B_i])

            # First-order index (Eq. S4.1)
            # S_i = V(E[Y|X_i]) / V(Y)
            S_i[i] = np.mean(Y_B * (Y_AB - Y_A)) / V_Y

            # Total-effect index (Eq. S4.2)
            # S_Ti = 1 - V(E[Y|X_~i]) / V(Y)
            S_Ti[i] = 0.5 * np.mean((Y_A - Y_AB)**2) / V_Y

        # Ensure indices are in [0, 1]
        S_i = np.clip(S_i, 0, 1)
        S_Ti = np.clip(S_Ti, 0, 1)

        return {
            'S_i': S_i,
            'S_Ti': S_Ti,
            'S_interaction': S_Ti - S_i,
            'param_names': param_names,
            'V_Y': V_Y,
            'N': N,
            'k': k
        }

    # ===== Morris Screening (SM S4.1) =====

    def morris_screening(self, model: Callable,
                        param_bounds: Dict[str, Tuple[float, float]],
                        r: Optional[int] = None,
                        delta: Optional[float] = None) -> Dict:
        """
        Morris elementary effects screening (SM S4.1, Eq. S4.3).

        EE_i = [f(x_1, ..., x_i + Delta, ..., x_k) - f(x)] / Delta

        Parameters:
        -----------
        model : callable
            Function y = model(params_dict)
        param_bounds : dict
            {param_name: (lower, upper)}
        r : int, optional
            Number of trajectories (uses config default if None)
        delta : float, optional
            Step size (default: 1/3 of parameter range)

        Returns:
        --------
        dict : {
            'mu': mean elementary effects,
            'mu_star': mean absolute elementary effects,
            'sigma': standard deviation of EEs,
            'param_names': parameter names
        }
        """
        if r is None:
            r = self.config.n_morris

        k = len(param_bounds)
        param_names = list(param_bounds.keys())

        if delta is None:
            delta = 1.0 / 3.0

        # Storage for elementary effects
        EE = np.zeros((r, k))

        for j in range(r):
            # Random starting point
            x0 = np.random.uniform(0, 1 - delta, size=k)

            # Random trajectory direction
            D = np.diag(np.random.choice([-1, 1], size=k))

            # Generate trajectory
            for i in range(k):
                x = x0.copy()
                x[i] += delta
                x = np.clip(x, 0, 1)

                x_plus = x0.copy()
                x_plus[i] += delta
                x_plus = np.clip(x_plus, 0, 1)

                # Scale to parameter bounds
                x_scaled = np.zeros(k)
                x_plus_scaled = np.zeros(k)
                for p, name in enumerate(param_names):
                    low, high = param_bounds[name]
                    x_scaled[p] = low + x[p] * (high - low)
                    x_plus_scaled[p] = low + x_plus[p] * (high - low)

                # Evaluate model
                y = model(dict(zip(param_names, x_scaled)))
                y_plus = model(dict(zip(param_names, x_plus_scaled)))

                # Compute elementary effect
                param_range = param_bounds[param_names[i]][1] - param_bounds[param_names[i]][0]
                EE[j, i] = (y_plus - y) / (delta * param_range)

        # Compute Morris measures
        mu = np.mean(EE, axis=0)
        mu_star = np.mean(np.abs(EE), axis=0)
        sigma = np.std(EE, axis=0)

        return {
            'mu': mu,
            'mu_star': mu_star,
            'sigma': sigma,
            'param_names': param_names,
            'EE': EE
        }

    def compare_sobol_morris(self, sobol_results: Dict, 
                            morris_results: Dict) -> Tuple[float, float]:
        """
        Compare Sobol and Morris rankings using Spearman correlation.

        Parameters:
        -----------
        sobol_results : dict
            Output from compute_sobol_indices
        morris_results : dict
            Output from morris_screening

        Returns:
        --------
        tuple : (Spearman rho, p-value)
        """
        # Rank parameters by S_Ti (Sobol) and mu_star (Morris)
        sobol_ranks = np.argsort(np.argsort(-sobol_results['S_Ti'])) + 1
        morris_ranks = np.argsort(np.argsort(-morris_results['mu_star'])) + 1

        rho, p_value = spearmanr(sobol_ranks, morris_ranks)

        return rho, p_value

    # ===== WLF Sensitivity Testing (SM S4.3) =====

    def wlf_sensitivity(self, model: Callable,
                       base_params: Dict,
                       C1_range: Tuple[float, float] = (0.8, 1.2),
                       C2_range: Tuple[float, float] = (0.8, 1.2)) -> Dict:
        """
        Test sensitivity to WLF parameters C1 and C2.

        Vary C1 and C2 within ±20% and compute change in cumulative release.

        Parameters:
        -----------
        model : callable
            Model function
        base_params : dict
            Base parameter set
        C1_range, C2_range : tuple
            Fractional variation ranges

        Returns:
        --------
        dict : sensitivity results
        """
        # Base case
        y_base = model(base_params)

        results = {}

        for param_name, (low_frac, high_frac) in [('C1', C1_range), ('C2', C2_range)]:
            variations = []

            for frac in [low_frac, 1.0, high_frac]:
                params = base_params.copy()
                if param_name == 'C1':
                    params['C1_wlf'] = base_params.get('C1_wlf', 17.5) * frac
                else:
                    params['C2_wlf'] = base_params.get('C2_wlf', 51.6) * frac

                y = model(params)
                change = (y - y_base) / y_base * 100
                variations.append(change)

            results[param_name] = {
                'low': variations[0],
                'base': variations[1],
                'high': variations[2],
                'range': max(variations) - min(variations)
            }

        return results

    # ===== Classification of Sensitivity =====

    @staticmethod
    def classify_sensitivity(S_Ti: float) -> str:
        """
        Classify parameter sensitivity level (Fig. 4a).

        Parameters:
        -----------
        S_Ti : float
            Total-effect Sobol index

        Returns:
        --------
        str : sensitivity class
        """
        if S_Ti > 0.3:
            return 'high'
        elif S_Ti > 0.15:
            return 'moderate'
        elif S_Ti > 0.05:
            return 'low'
        else:
            return 'negligible'

    def full_analysis(self, model: Callable,
                     param_bounds: Dict[str, Tuple[float, float]],
                     output_names: List[str] = None) -> Dict:
        """
        Perform complete sensitivity analysis.

        Parameters:
        -----------
        model : callable
            Model function
        param_bounds : dict
            Parameter bounds
        output_names : list, optional
            Names of output variables

        Returns:
        --------
        dict : complete sensitivity results
        """
        if output_names is None:
            output_names = ['M_rel_1yr', 'C_max', 'F_leach']

        results = {}

        for i, name in enumerate(output_names):
            print(f"Analyzing sensitivity for: {name}")

            # Sobol analysis
            sobol = self.compute_sobol_indices(model, param_bounds, 
                                              output_index=i)

            # Morris screening
            morris = self.morris_screening(model, param_bounds)

            # Compare rankings
            rho, p = self.compare_sobol_morris(sobol, morris)

            results[name] = {
                'sobol': sobol,
                'morris': morris,
                'spearman_rho': rho,
                'spearman_p': p
            }

            # Print summary
            print(f"  Spearman correlation: rho = {rho:.3f}, p = {p:.4f}")
            print(f"  Top 3 drivers (S_Ti):")
            idx = np.argsort(-sobol['S_Ti'])[:3]
            for j in idx:
                print(f"    {sobol['param_names'][j]}: {sobol['S_Ti'][j]:.3f} "
                      f"({self.classify_sensitivity(sobol['S_Ti'][j])})")

        return results
