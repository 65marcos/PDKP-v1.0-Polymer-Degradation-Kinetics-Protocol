"""
Validation and Benchmarking Module
=====================================
Model performance assessment against field data and alternative models.

Metrics implemented (Moriasi et al. 2007):
  - Nash-Sutcliffe Efficiency (NSE)
  - Percent Bias (PBIAS)
  - RMSE-observations standard deviation ratio (RSR)
  - Coefficient of determination (R²)

SM S6.1: Complete validation dataset from Xinjiang cotton fields
SM S6.2: Benchmarking against FODM and HYDRUS-1D
SM S10: Transferability assessment across four Chinese regions
"""

import numpy as np
from scipy import stats
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass


@dataclass
class ValidationResult:
    """Container for validation metrics"""
    NSE: float
    PBIAS: float
    RSR: float
    R2: float
    n: int
    performance_class: str

    def __repr__(self):
        return (f"NSE={self.NSE:.3f}, PBIAS={self.PBIAS:+.1f}%, "
                f"RSR={self.RSR:.3f}, R²={self.R2:.3f}, "
                f"n={self.n}, class={self.performance_class}")


class ValidationMetrics:
    """
    Model validation metrics following Moriasi et al. (2007) guidelines.
    """

    # Performance thresholds (Table 4, main text)
    NSE_THRESHOLDS = {
        'very_good': 0.75,
        'good': 0.65,
        'acceptable': 0.50
    }

    PBIAS_THRESHOLDS = {
        'good': 10.0,
        'acceptable': 25.0
    }

    RSR_THRESHOLDS = {
        'good': 0.50,
        'acceptable': 0.70
    }

    R2_THRESHOLDS = {
        'good': 0.70,
        'acceptable': 0.50
    }

    @staticmethod
    def nash_sutcliffe(observed: np.ndarray, 
                      predicted: np.ndarray) -> float:
        """
        Nash-Sutcliffe Efficiency (NSE).

        NSE = 1 - sum((O_i - P_i)^2) / sum((O_i - O_mean)^2)

        Parameters:
        -----------
        observed, predicted : array
            Observed and predicted values

        Returns:
        --------
        float : NSE in (-inf, 1]
        """
        obs_mean = np.mean(observed)
        ss_res = np.sum((observed - predicted)**2)
        ss_tot = np.sum((observed - obs_mean)**2)

        if ss_tot == 0:
            return 1.0 if ss_res == 0 else -np.inf

        return 1.0 - ss_res / ss_tot

    @staticmethod
    def percent_bias(observed: np.ndarray,
                    predicted: np.ndarray) -> float:
        """
        Percent Bias (PBIAS).

        PBIAS = 100 * sum(P_i - O_i) / sum(O_i)

        Parameters:
        -----------
        observed, predicted : array
            Observed and predicted values

        Returns:
        --------
        float : PBIAS in %
        """
        return 100.0 * np.sum(predicted - observed) / np.sum(observed)

    @staticmethod
    def rmse_std_ratio(observed: np.ndarray,
                      predicted: np.ndarray) -> float:
        """
        RMSE-observations standard deviation ratio (RSR).

        RSR = RMSE / STD_obs

        Parameters:
        -----------
        observed, predicted : array
            Observed and predicted values

        Returns:
        --------
        float : RSR
        """
        rmse = np.sqrt(np.mean((observed - predicted)**2))
        std_obs = np.std(observed, ddof=1)

        if std_obs == 0:
            return 0.0 if rmse == 0 else np.inf

        return rmse / std_obs

    @staticmethod
    def coefficient_of_determination(observed: np.ndarray,
                                    predicted: np.ndarray) -> float:
        """
        Coefficient of determination (R²).

        R² = [sum((O_i - O_mean)(P_i - P_mean)) / 
              sqrt(sum((O_i - O_mean)²) * sum((P_i - P_mean)²))]²

        Parameters:
        -----------
        observed, predicted : array
            Observed and predicted values

        Returns:
        --------
        float : R² in [0, 1]
        """
        slope, intercept, r_value, p_value, std_err = stats.linregress(
            observed, predicted)
        return r_value**2

    def compute_all(self, observed: np.ndarray,
                   predicted: np.ndarray) -> ValidationResult:
        """
        Compute all validation metrics.

        Parameters:
        -----------
        observed, predicted : array
            Observed and predicted values

        Returns:
        --------
        ValidationResult : all metrics and performance class
        """
        nse = self.nash_sutcliffe(observed, predicted)
        pbias = self.percent_bias(observed, predicted)
        rsr = self.rmse_std_ratio(observed, predicted)
        r2 = self.coefficient_of_determination(observed, predicted)
        n = len(observed)

        # Determine performance class
        perf_class = self._classify_performance(nse, pbias, rsr, r2)

        return ValidationResult(
            NSE=nse, PBIAS=pbias, RSR=rsr, R2=r2,
            n=n, performance_class=perf_class
        )

    def _classify_performance(self, nse: float, pbias: float,
                             rsr: float, r2: float) -> str:
        """Classify overall performance based on all metrics."""
        # Count metrics in each class
        good_count = 0
        acceptable_count = 0

        # NSE
        if nse >= self.NSE_THRESHOLDS['very_good']:
            good_count += 2
        elif nse >= self.NSE_THRESHOLDS['good']:
            good_count += 1
        elif nse >= self.NSE_THRESHOLDS['acceptable']:
            acceptable_count += 1

        # PBIAS
        if abs(pbias) <= self.PBIAS_THRESHOLDS['good']:
            good_count += 1
        elif abs(pbias) <= self.PBIAS_THRESHOLDS['acceptable']:
            acceptable_count += 1

        # RSR
        if rsr <= self.RSR_THRESHOLDS['good']:
            good_count += 1
        elif rsr <= self.RSR_THRESHOLDS['acceptable']:
            acceptable_count += 1

        # R²
        if r2 >= self.R2_THRESHOLDS['good']:
            good_count += 1
        elif r2 >= self.R2_THRESHOLDS['acceptable']:
            acceptable_count += 1

        # Overall classification
        if good_count >= 3:
            return 'good'
        elif good_count + acceptable_count >= 3:
            return 'acceptable'
        else:
            return 'unsatisfactory'

    # ===== Benchmarking Against Alternative Models (SM S6.2) =====

    def benchmark_models(self, observed: np.ndarray,
                        predictions: Dict[str, np.ndarray]) -> Dict:
        """
        Benchmark PDKP against alternative models (Table 5).

        Parameters:
        -----------
        observed : array
            Observed values
        predictions : dict
            {model_name: predicted_values}

        Returns:
        --------
        dict : validation results for each model
        """
        results = {}

        for model_name, predicted in predictions.items():
            result = self.compute_all(observed, predicted)
            results[model_name] = result

        return results

    # ===== Time-Resolved Benchmarking (SM S10.3) =====

    def time_resolved_benchmark(self, observed: np.ndarray,
                               predictions: Dict[str, np.ndarray],
                               time_points: np.ndarray) -> Dict:
        """
        Compute metrics at each time point (SM S10.3, Table).

        Parameters:
        -----------
        observed : array
            Observed values (n_timepoints x n_replicates)
        predictions : dict
            {model_name: predicted_values (n_timepoints)}
        time_points : array
            Time points in months

        Returns:
        --------
        dict : time-resolved metrics
        """
        results = {'time': time_points}

        for model_name, predicted in predictions.items():
            nse_series = []
            pbias_series = []
            r2_series = []

            for i, t in enumerate(time_points):
                obs_t = observed[i] if observed.ndim > 1 else observed[i:i+1]
                pred_t = np.full_like(obs_t, predicted[i])

                nse = self.nash_sutcliffe(obs_t, pred_t)
                pbias = self.percent_bias(obs_t, pred_t)
                r2 = self.coefficient_of_determination(obs_t, pred_t)

                nse_series.append(nse)
                pbias_series.append(pbias)
                r2_series.append(r2)

            results[model_name] = {
                'NSE': np.array(nse_series),
                'PBIAS': np.array(pbias_series),
                'R2': np.array(r2_series),
                'mean_NSE': np.mean(nse_series),
                'mean_PBIAS': np.mean(pbias_series),
                'mean_R2': np.mean(r2_series)
            }

        return results

    # ===== Transferability Assessment (SM S10.1, S10.2) =====

    def assess_transferability(self, 
                              regional_results: Dict[str, ValidationResult],
                              reference_region: str = 'Xinjiang') -> Dict:
        """
        Assess model transferability across regions (SM S10.2).

        Parameters:
        -----------
        regional_results : dict
            {region_name: ValidationResult}
        reference_region : str
            Reference region for comparison

        Returns:
        --------
        dict : transferability metrics
        """
        ref = regional_results[reference_region]

        transferability = {}
        for region, result in regional_results.items():
            if region == reference_region:
                continue

            delta_nse = result.NSE - ref.NSE

            transferability[region] = {
                'NSE': result.NSE,
                'delta_NSE': delta_nse,
                'PBIAS': result.PBIAS,
                'R2': result.R2,
                'degradation': 'acceptable' if delta_nse > -0.15 else 'poor'
            }

        return transferability

    # ===== Leave-One-Study-Out Cross-Validation (SM S3.2.4) =====

    @staticmethod
    def losocv(predictions: List[np.ndarray],
                observations: List[np.ndarray]) -> Dict:
        """
        Leave-one-study-out cross-validation (SM S3.2.4).

        Parameters:
        -----------
        predictions : list of arrays
            Predicted values for each study
        observations : list of arrays
            Observed values for each study

        Returns:
        --------
        dict : LOSO-CV results
        """
        n_studies = len(predictions)
        rmse_values = []

        for i in range(n_studies):
            # Test on study i
            pred_test = predictions[i]
            obs_test = observations[i]

            # Train on all other studies
            train_pred = np.concatenate([predictions[j] for j in range(n_studies) if j != i])
            train_obs = np.concatenate([observations[j] for j in range(n_studies) if j != i])

            # Compute RMSE for test study
            rmse = np.sqrt(np.mean((pred_test - obs_test)**2))
            rmse_values.append(rmse)

        return {
            'rmse_mean': np.mean(rmse_values),
            'rmse_std': np.std(rmse_values),
            'rmse_min': np.min(rmse_values),
            'rmse_max': np.max(rmse_values),
            'rmse_all': rmse_values
        }
