"""
Module III: Soil Transport
============================
Simulates advection-dispersion, sorption-desorption, and root uptake,
producing depth-resolved concentration profiles and cumulative leaching fluxes.

Equations implemented:
  Eq. 10: Advection-dispersion equation for dissolved concentration

SM S7.1: von Neumann stability analysis and mesh independence
SM S7.2: Monte Carlo convergence via Gelman-Rubin diagnostic
SM S12.4: Two-site desorption model with hysteresis
SM S12.5: Depth-dependent UV attenuation
"""

import numpy as np
from scipy.integrate import solve_ivp
from scipy.sparse import diags
from scipy.sparse.linalg import spsolve
from dataclasses import dataclass
from typing import Dict, Optional, Callable, Tuple
import warnings


@dataclass
class TransportParams:
    """Parameters for soil transport module"""
    D_eff: float = 1e-9      # m^2/day, effective dispersion coefficient
    v: float = 0.01          # m/day, pore water velocity
    rho_b: float = 1350.0    # kg/m^3, bulk density
    theta: float = 0.20      # m^3/m^3, volumetric water content
    lambda_bio: float = 0.01 # day^-1, biodegradation rate
    lambda_phot: float = 0.001 # day^-1, photolysis rate
    z_max: float = 1.0       # m, maximum soil depth
    n_z: int = 100           # number of depth nodes
    dt: float = 0.1          # day, time step


class SoilTransport:
    """
    Module III: Soil Transport

    Solves 1D advection-dispersion equation with sorption,
    biodegradation, and source terms.
    """

    def __init__(self, params: Optional[TransportParams] = None):
        """
        Initialize soil transport module.

        Parameters:
        -----------
        params : TransportParams, optional
            Transport parameters (uses defaults if None)
        """
        self.params = params if params is not None else TransportParams()

        # Spatial discretization
        self.dz = self.params.z_max / self.params.n_z
        self.z = np.linspace(0, self.params.z_max, self.params.n_z)

        # Verify stability criteria (SM S7.1)
        self._verify_stability()

    def _verify_stability(self):
        """Verify numerical stability criteria (SM S7.1, Eq. S7.3-S7.4)"""
        Pe = self.params.v * self.dz / self.params.D_eff
        Co = self.params.v * self.params.dt / self.dz

        if Pe >= 2.0:
            warnings.warn(f"Mesh Peclet number {Pe:.2f} >= 2. "
                         f"Numerical diffusion may dominate. "
                         f"Consider finer mesh.")

        print(f"Stability check: Pe = {Pe:.3f}, Co = {Co:.3f}")
        print(f"  Pe < 2: {'PASS' if Pe < 2 else 'WARNING'}")
        print(f"  dz = {self.dz*100:.1f} cm, dt = {self.params.dt} day")

    # ===== Advection-Dispersion Equation (Eq. 10) =====

    def build_dispersion_matrix(self) -> np.ndarray:
        """
        Build finite difference matrix for dispersion operator.

        Uses second-order central differences for dispersion
        and first-order upwind for advection.

        Returns:
        --------
        ndarray : (n_z, n_z) sparse matrix representation
        """
        n = self.params.n_z
        dz = self.dz
        D = self.params.D_eff
        v = self.params.v

        # Coefficients for interior points
        # D_eff * d2C/dz2 - v * dC/dz
        # Central difference for dispersion, upwind for advection

        a = D / dz**2 + v / dz   # coefficient for C[i-1]
        b = -2 * D / dz**2 - v / dz  # coefficient for C[i]
        c = D / dz**2             # coefficient for C[i+1]

        # Build tridiagonal matrix
        lower = np.full(n-1, c)
        diag = np.full(n, b)
        upper = np.full(n-1, a)

        # Boundary conditions
        # Top (z=0): Dirichlet or flux boundary
        diag[0] = -D / dz**2 - v / dz
        upper[0] = D / dz**2

        # Bottom (z=z_max): zero gradient (Neumann)
        lower[-1] = D / dz**2 + v / dz
        diag[-1] = -D / dz**2 - v / dz

        # Create sparse matrix
        from scipy.sparse import diags as sp_diags
        A = sp_diags([lower, diag, upper], [-1, 0, 1], format='csr')

        return A

    def solve_steady_state(self, R_source: np.ndarray,
                          K_d: float,
                          lambda_bio: Optional[float] = None) -> np.ndarray:
        """
        Solve steady-state advection-dispersion equation.

        0 = D_eff * d2C/dz2 - v * dC/dz - (rho_b/theta) * lambda_s * C
            - lambda_bio * C - lambda_phot * C + R_source

        Parameters:
        -----------
        R_source : array
            Source term (mg/L/day) at each depth node
        K_d : float
            Distribution coefficient (L/kg)
        lambda_bio : float, optional
            Biodegradation rate (uses params default if None)

        Returns:
        --------
        array : steady-state concentration profile C_w(z) in mg/L
        """
        if lambda_bio is None:
            lambda_bio = self.params.lambda_bio

        n = self.params.n_z
        rho_b = self.params.rho_b
        theta = self.params.theta

        # Build system matrix including reaction terms
        A = self.build_dispersion_matrix().toarray()

        # Add reaction terms (diagonal)
        lambda_s = 0.0  # sorption rate (instantaneous equilibrium)
        reaction = (rho_b / theta) * lambda_s + lambda_bio + self.params.lambda_phot
        A[np.arange(n), np.arange(n)] -= reaction

        # Solve linear system
        C_w = np.linalg.solve(A, -R_source)

        return np.maximum(C_w, 0)  # ensure non-negative

    def solve_transient(self, t_span: Tuple[float, float],
                       C_w0: np.ndarray,
                       R_source: Callable,
                       K_d: float,
                       t_eval: Optional[np.ndarray] = None) -> solve_ivp:
        """
        Solve transient advection-dispersion equation.

        dC_w/dt = D_eff * d2C_w/dz2 - v * dC_w/dz
                  - (rho_b/theta) * dS/dt
                  - lambda_bio * C_w - lambda_phot * C_w + R_source(z,t)

        Parameters:
        -----------
        t_span : tuple
            (t_start, t_end) in days
        C_w0 : array
            Initial concentration profile (mg/L)
        R_source : callable
            Function R_source(z, t) returning source term
        K_d : float
            Distribution coefficient
        t_eval : array, optional
            Time points for output

        Returns:
        --------
        OdeResult : SciPy solve_ivp result
        """
        n = self.params.n_z
        dz = self.dz
        D = self.params.D_eff
        v = self.params.v
        rho_b = self.params.rho_b
        theta = self.params.theta

        # Build spatial operators
        # Second derivative (dispersion): central differences
        d2 = np.zeros((n, n))
        for i in range(1, n-1):
            d2[i, i-1] = 1.0
            d2[i, i] = -2.0
            d2[i, i+1] = 1.0
        d2 = d2 / dz**2

        # First derivative (advection): upwind
        d1 = np.zeros((n, n))
        for i in range(1, n):
            d1[i, i-1] = -1.0
            d1[i, i] = 1.0
        d1 = d1 / dz

        # Reaction matrix
        reaction = -(rho_b / theta) * 0 - self.params.lambda_bio - self.params.lambda_phot

        def ode(t, C_w):
            # Source term
            R = np.array([R_source(z_i, t) for z_i in self.z])

            # Dispersion + advection + reactions
            dCdt = D * (d2 @ C_w) - v * (d1 @ C_w) + reaction * C_w + R

            # Boundary conditions
            dCdt[0] = 0  # fixed concentration at surface
            dCdt[-1] = 0  # zero flux at bottom

            return dCdt

        sol = solve_ivp(ode, t_span, C_w0, method='BDF',
                       t_eval=t_eval, rtol=1e-6, atol=1e-9)
        return sol

    # ===== Two-Site Desorption Model (SM S12.4) =====

    def solve_two_site(self, t_span: Tuple[float, float],
                      C_w0: float,
                      S_fast0: float,
                      S_slow0: float,
                      K_d: float,
                      f_slow: float,
                      k_s_slow: float,
                      k_d_slow: float,
                      R_source: Callable,
                      t_eval: Optional[np.ndarray] = None) -> solve_ivp:
        """
        Solve transport with two-site sorption model (SM S12.4, Eq. S12.5-S12.10).

        S = S_fast + S_slow
        dS_fast/dt = k_s,fast * (1-f_slow) * K_d * C_w - k_d,fast * S_fast
        dS_slow/dt = k_s,slow * f_slow * K_d * C_w - k_d,slow * S_slow

        Parameters:
        -----------
        t_span : tuple
            Time range
        C_w0, S_fast0, S_slow0 : float
            Initial concentrations
        K_d : float
            Distribution coefficient
        f_slow : float
            Fraction of slow sites
        k_s_slow, k_d_slow : float
            Slow site forward/reverse rates (day^-1)
        R_source : callable
            Source function
        t_eval : array, optional
            Output time points

        Returns:
        --------
        OdeResult : solution with y = [C_w, S_fast, S_slow]
        """
        rho_b = self.params.rho_b
        theta = self.params.theta

        # Fast sites: instantaneous equilibrium
        # S_fast = (1 - f_slow) * K_d * C_w

        def ode(t, y):
            C_w, S_slow = y[0], y[1]

            S_fast = (1 - f_slow) * K_d * C_w

            # Source term
            R = R_source(0, t)  # simplified: single depth

            # Slow site dynamics
            dS_slow_dt = k_s_slow * f_slow * K_d * C_w - k_d_slow * S_slow

            # Aqueous phase balance
            dC_w_dt = (- (rho_b / theta) * dS_slow_dt
                       - self.params.lambda_bio * C_w
                       - self.params.lambda_phot * C_w
                       + R)

            return [dC_w_dt, dS_slow_dt]

        sol = solve_ivp(ode, t_span, [C_w0, S_slow0], method='BDF',
                       t_eval=t_eval, rtol=1e-6, atol=1e-9)
        return sol

    # ===== Depth-Dependent UV Attenuation (SM S12.5) =====

    @staticmethod
    def uv_attenuation_coefficient(theta: float, f_OC: float) -> float:
        """
        Compute UV attenuation coefficient in soil (SM S12.5, Eq. S12.12).

        k_att = k_dry + beta_moist,UV * theta + gamma_OM,UV * f_OC

        Parameters:
        -----------
        theta : float
            Volumetric water content (m^3/m^3)
        f_OC : float
            Fraction organic carbon

        Returns:
        --------
        float : k_att in cm^-1
        """
        k_dry = 2.0        # cm^-1
        beta_moist = 8.0   # cm^-1
        gamma_OM = 15.0    # cm^-1

        return k_dry + beta_moist * theta + gamma_OM * f_OC

    @staticmethod
    def effective_uv_factor(I_UV_surface: float, I_ref: float,
                           alpha_UV: float, k_att: float,
                           Z_max: float) -> float:
        """
        Compute depth-averaged effective UV factor (SM S12.5, Eq. S12.14).

        f_UV,eff = (I_UV(0)/I_ref)^alpha_UV * [1 - exp(-alpha_UV * k_att * Z_max)] 
                    / (alpha_UV * k_att * Z_max)

        Parameters:
        -----------
        I_UV_surface : float
            Surface UV irradiance (W/m^2)
        I_ref : float
            Reference irradiance
        alpha_UV : float
            UV scaling exponent
        k_att : float
            Attenuation coefficient (cm^-1)
        Z_max : float
            Maximum burial depth (cm)

        Returns:
        --------
        float : effective UV factor
        """
        base = (I_UV_surface / I_ref) ** alpha_UV

        exponent = alpha_UV * k_att * Z_max
        attenuation = (1.0 - np.exp(-exponent)) / exponent

        return base * attenuation

    # ===== Photo-Fenton Chemistry (SM S12.5) =====

    @staticmethod
    def photo_fenton_rate(Fe2_conc: float, I_UV: float,
                         k_att: float, z: float,
                         k_OH_add: float = 1e10) -> float:
        """
        Compute additive degradation rate via photo-Fenton (SM S12.5).

        R_OH = phi_OH * [Fe2+] * I_UV(0) * exp(-k_att * z)
        lambda_phot,Fenton = k_OH,add * [OH]

        Parameters:
        -----------
        Fe2_conc : float
            Fe2+ concentration (M)
        I_UV : float
            Surface UV irradiance
        k_att : float
            UV attenuation coefficient
        z : float
            Depth (cm)
        k_OH_add : float
            OH radical reaction rate constant (M^-1 s^-1)

        Returns:
        --------
        float : lambda_phot,Fenton in day^-1
        """
        phi_OH = 0.03  # mol OH / mol photons

        I_UV_z = I_UV * np.exp(-k_att * z)
        R_OH = phi_OH * Fe2_conc * I_UV_z

        # Convert to day^-1
        lambda_fenton = k_OH_add * R_OH * 86400  # s/day

        return lambda_fenton

    # ===== Leaching Flux =====

    def compute_leaching_flux(self, C_w: np.ndarray) -> float:
        """
        Compute cumulative leaching flux at bottom boundary.

        Flux = v * C_w(z_max) * theta

        Parameters:
        -----------
        C_w : array
            Concentration profile at final time

        Returns:
        --------
        float : leaching flux in mg/m^2/day
        """
        return self.params.v * C_w[-1] * self.params.theta * 1000  # mg/L to mg/m^3

    # ===== Mesh Independence Verification (SM S7.1.4) =====

    def verify_mesh_independence(self, R_source: Callable, K_d: float,
                                dz_values: list = None) -> Dict:
        """
        Verify mesh independence by comparing solutions at different resolutions.

        Parameters:
        -----------
        R_source : callable
            Source function
        K_d : float
            Distribution coefficient
        dz_values : list, optional
            List of dz values to test (default: [2, 1, 0.5] cm)

        Returns:
        --------
        dict : results with L2 norms
        """
        if dz_values is None:
            dz_values = [0.02, 0.01, 0.005]  # m

        results = {}
        prev_solution = None

        for dz in dz_values:
            n_z = int(self.params.z_max / dz)
            temp_params = TransportParams(
                z_max=self.params.z_max, n_z=n_z,
                D_eff=self.params.D_eff, v=self.params.v
            )
            temp_solver = SoilTransport(temp_params)

            R = np.array([R_source(z_i, 0) for z_i in temp_solver.z])
            C_w = temp_solver.solve_steady_state(R, K_d)

            results[dz] = {
                'n_z': n_z,
                'C_w': C_w,
                'peak': np.max(C_w)
            }

            if prev_solution is not None:
                # Interpolate to coarser grid for comparison
                from scipy.interpolate import interp1d
                f_interp = interp1d(temp_solver.z, C_w, kind='linear',
                                   fill_value='extrapolate')
                C_w_interp = f_interp(prev_z)

                l2_norm = np.linalg.norm(C_w_interp - prev_solution) / np.linalg.norm(prev_solution)
                results[dz]['l2_relative'] = l2_norm * 100  # %

            prev_solution = C_w
            prev_z = temp_solver.z

        return results
