"""
Scenario Projections Module
==============================
Future projections of microplastic-associated additive dynamics
under climate change and alternative management strategies.

Equations implemented:
  SM S8.1: CMIP6 climate downscaling via quantile mapping
  SM S8.2: Management scenario definitions
  SM S11.1: Groundwater leaching projections
  SM S11.2: Integrated scenario assessment
  SM S11.3: Regional probability maps
  SM S12.2: Cost-effectiveness analysis framework
"""

import numpy as np
from scipy.interpolate import interp1d
from scipy.stats import norm
from typing import Dict, List, Tuple, Optional, Callable
from dataclasses import dataclass


@dataclass
class ClimateProjection:
    """CMIP6 climate projection data (Table S8.1)"""
    region: str
    delta_T: float      # °C, temperature change by 2050
    delta_P: float      # mm/year, precipitation change
    delta_UV: float     # MJ/m²/year, UV change
    delta_irrigation: float  # mm, irrigation need change
    gcm_spread: Tuple[float, float, float, float]  # ±1σ for each variable


@dataclass
class ManagementScenario:
    """Management scenario parameters (Table S8.2)"""
    name: str
    mulch_type: str
    thickness_um: float
    application_rate: float  # kg/ha
    collection_rate: float     # %
    tillage: str
    irrigation: float        # mm/season
    mulch_cost: float         # CNY/kg
    labor_cost_factor: float  # relative to BAU


# Climate projections for Chinese regions (Table S8.1)
CLIMATE_PROJECTIONS = {
    'Xinjiang': ClimateProjection(
        'Xinjiang', delta_T=1.8, delta_P=-15, delta_UV=35,
        delta_irrigation=45, gcm_spread=(0.4, 25, 12, 20)
    ),
    'North_China_Plain': ClimateProjection(
        'North China Plain', delta_T=1.6, delta_P=20, delta_UV=18,
        delta_irrigation=15, gcm_spread=(0.3, 30, 10, 15)
    ),
    'Yangtze_Delta': ClimateProjection(
        'Yangtze Delta', delta_T=1.4, delta_P=55, delta_UV=8,
        delta_irrigation=-25, gcm_spread=(0.3, 40, 8, 20)
    ),
    'Northeast_China': ClimateProjection(
        'Northeast China', delta_T=2.1, delta_P=70, delta_UV=22,
        delta_irrigation=-10, gcm_spread=(0.5, 35, 15, 15)
    ),
}


# Management scenarios (Table S8.2)
MANAGEMENT_SCENARIOS = {
    'BAU': ManagementScenario(
        'Business-as-Usual', 'PE', 6, 60, 0, 'Conventional', 450,
        mulch_cost=12, labor_cost_factor=1.0
    ),
    'Biodegradable': ManagementScenario(
        'Biodegradable mulch', 'PLA/PBAT', 8, 75, 0, 'Conventional', 400,
        mulch_cost=28, labor_cost_factor=1.2
    ),
    'Reduced_Thickness': ManagementScenario(
        'Reduced thickness', 'PE', 3, 30, 0, 'Conventional', 450,
        mulch_cost=12, labor_cost_factor=1.0
    ),
    'Enhanced_Collection': ManagementScenario(
        'Enhanced collection', 'PE', 6, 60, 90, 'Conventional', 450,
        mulch_cost=12, labor_cost_factor=1.15
    ),
    'No_Till': ManagementScenario(
        'No-till + residue', 'PE', 6, 60, 0, 'Zero', 400,
        mulch_cost=12, labor_cost_factor=0.7
    ),
    'Combined': ManagementScenario(
        'Combined optimal', 'PLA/PBAT', 3, 45, 90, 'Zero', 350,
        mulch_cost=28, labor_cost_factor=0.85
    ),
}


class ScenarioProjections:
    """
    Future scenario projections for microplastic-associated additive dynamics.
    """

    def __init__(self, base_year: int = 2020, projection_year: int = 2050):
        self.base_year = base_year
        self.projection_year = projection_year
        self.years = np.arange(base_year, projection_year + 1)

    # ===== CMIP6 Climate Downscaling (SM S8.1) =====

    @staticmethod
    def quantile_mapping_bias_correction(X_raw: np.ndarray,
                                          F_gcm: Callable,
                                          F_obs: Callable) -> np.ndarray:
        """
        Quantile mapping bias correction (SM S8.1, Eq. S8.1).

        X_corrected = F_obs^(-1)(F_gcm(X_raw))

        Parameters:
        -----------
        X_raw : array
            Raw GCM output
        F_gcm : callable
            GCM cumulative distribution function
        F_obs : callable
            Observed CDF (ERA5 reanalysis)

        Returns:
        --------
        array : bias-corrected values
        """
        # Compute GCM quantiles
        gcm_quantiles = F_gcm(X_raw)

        # Map to observed distribution
        X_corrected = F_obs.ppf(gcm_quantiles)

        return X_corrected

    def project_climate(self, region: str,
                       historical_data: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        """
        Project climate variables to 2050 using CMIP6 SSP2-4.5.

        Parameters:
        -----------
        region : str
            Region name
        historical_data : dict
            {variable: historical_time_series}

        Returns:
        --------
        dict : projected climate variables
        """
        proj = CLIMATE_PROJECTIONS[region]

        # Linear trend from base_year to projection_year
        n_years = self.projection_year - self.base_year

        projected = {}
        for var, hist in historical_data.items():
            hist_mean = np.mean(hist)

            if var == 'temperature':
                delta = proj.delta_T
            elif var == 'precipitation':
                delta = proj.delta_P
            elif var == 'UV':
                delta = proj.delta_UV
            elif var == 'irrigation':
                delta = proj.delta_irrigation
            else:
                delta = 0

            # Linear interpolation
            trend = np.linspace(0, delta, len(self.years))
            projected[var] = hist_mean + trend

        return projected

    # ===== Scenario Comparison (SM S11.2, Table) =====

    def evaluate_scenario(self, scenario: ManagementScenario,
                         base_model: Callable,
                         base_params: Dict) -> Dict:
        """
        Evaluate a management scenario.

        Parameters:
        -----------
        scenario : ManagementScenario
            Scenario to evaluate
        base_model : callable
            PDKP model function
        base_params : dict
            Base parameters

        Returns:
        --------
        dict : scenario results
        """
        params = base_params.copy()

        # Update parameters based on scenario
        params['polymer_type'] = scenario.mulch_type
        params['mulch_rate'] = scenario.application_rate
        params['collection_efficiency'] = scenario.collection_rate / 100.0
        params['irrigation'] = scenario.irrigation

        # Run model
        result = base_model(params)

        # Compute costs
        material_cost = scenario.application_rate * scenario.mulch_cost
        labor_cost = base_params.get('base_labor_cost', 3600) * scenario.labor_cost_factor
        total_cost = material_cost + labor_cost

        return {
            'leaching': result['leaching'],
            'soil_mp_mass': result['soil_mp_mass'],
            'yield': result['yield'],
            'cost': total_cost,
            'ghg_emissions': result['ghg_emissions'],
            'water_use': scenario.irrigation
        }

    def compare_scenarios(self, base_model: Callable,
                         base_params: Dict) -> Dict:
        """
        Compare all management scenarios (SM S11.2, Table).

        Parameters:
        -----------
        base_model : callable
            PDKP model function
        base_params : dict
            Base parameters

        Returns:
        --------
        dict : comparison results for all scenarios
        """
        results = {}
        bau_result = None

        for name, scenario in MANAGEMENT_SCENARIOS.items():
            result = self.evaluate_scenario(scenario, base_model, base_params)
            results[name] = result

            if name == 'BAU':
                bau_result = result

        # Compute relative changes
        for name, result in results.items():
            if bau_result is not None:
                result['leaching_reduction'] = (
                    (bau_result['leaching'] - result['leaching']) 
                    / bau_result['leaching'] * 100
                )
                result['soil_mp_change'] = (
                    result['soil_mp_mass'] / bau_result['soil_mp_mass'] * 100
                )
                result['cost_index'] = (
                    result['cost'] / bau_result['cost'] * 100
                )
                result['yield_change'] = (
                    (result['yield'] - bau_result['yield']) 
                    / bau_result['yield'] * 100
                )
                result['ghg_reduction'] = (
                    (bau_result['ghg_emissions'] - result['ghg_emissions'])
                    / bau_result['ghg_emissions'] * 100
                )

        return results

    # ===== Cost-Effectiveness Analysis (SM S12.2) =====

    def cost_effectiveness_analysis(self, scenario_results: Dict,
                                   daly_per_kg: float = 0.001) -> Dict:
        """
        Compute incremental cost-effectiveness ratios (SM S12.2, Eq. S12.4).

        ICER = (Cost_i - Cost_{i-1}) / (Effectiveness_i - Effectiveness_{i-1})

        Parameters:
        -----------
        scenario_results : dict
            Output from compare_scenarios
        daly_per_kg : float
            DALYs averted per kg leaching reduction

        Returns:
        --------
        dict : ICER results
        """
        # Sort scenarios by effectiveness (leaching reduction)
        sorted_scenarios = sorted(
            scenario_results.items(),
            key=lambda x: x[1]['leaching_reduction']
        )

        icer_results = []
        prev_cost = None
        prev_effectiveness = None

        for name, result in sorted_scenarios:
            effectiveness = result['leaching_reduction'] * daly_per_kg
            cost = result['cost']

            if prev_cost is not None:
                delta_cost = cost - prev_cost
                delta_effectiveness = effectiveness - prev_effectiveness

                if delta_effectiveness > 0:
                    icer = delta_cost / delta_effectiveness
                else:
                    icer = np.inf
            else:
                icer = 0  # reference scenario

            icer_results.append({
                'scenario': name,
                'cost': cost,
                'effectiveness': effectiveness,
                'delta_cost': delta_cost if prev_cost else 0,
                'delta_effectiveness': delta_effectiveness if prev_effectiveness else 0,
                'ICER': icer,
                'cost_effective': icer < 72000  # Chinese GDP per capita threshold
            })

            prev_cost = cost
            prev_effectiveness = effectiveness

        return {'icer_results': icer_results}

    # ===== Regional Probability Maps (SM S11.3) =====

    def regional_exceedance_probability(self,
                                       regional_params: Dict[str, Dict],
                                       regulatory_limit: float,
                                       n_mc: int = 10000) -> Dict:
        """
        Compute probability of exceeding regulatory limits by region.

        Parameters:
        -----------
        regional_params : dict
            {region: {parameter_distributions}}
        regulatory_limit : float
            Regulatory threshold
        n_mc : int
            Monte Carlo samples

        Returns:
        --------
        dict : exceedance probabilities by region
        """
        from .monte_carlo import MonteCarloPropagation

        mc = MonteCarloPropagation(n_samples=n_mc)
        results = {}

        for region, params in regional_params.items():
            # Generate samples
            # Simplified: assume log-normal distribution for peak concentration
            mu = params['mean_peak']
            sigma = params['std_peak']

            samples = np.random.lognormal(np.log(mu), sigma / mu, n_mc)

            # Compute exceedance probability
            p_exceed = np.mean(samples > regulatory_limit)

            results[region] = {
                'P_exceed': p_exceed,
                'mean_peak': mu,
                'std_peak': sigma,
                'recommended_intervention': self._recommend_intervention(p_exceed)
            }

        return results

    def _recommend_intervention(self, p_exceed: float) -> str:
        """Recommend intervention based on exceedance probability."""
        if p_exceed > 0.5:
            return 'Combined scenario priority'
        elif p_exceed > 0.2:
            return 'Reduced thickness or enhanced collection'
        else:
            return 'Monitor only'

    # ===== Yield Response Functions (SM S5.2, Eq. S5.1) =====

    @staticmethod
    def biodegradable_yield_penalty(t: float, 
                                     beta_bio: float = 0.12,
                                     k_frag: float = 0.15) -> float:
        """
        Time-dependent yield penalty for biodegradable mulch (Eq. S5.1).

        Y(t) = Y_BAU * [1 - beta_bio * (1 - exp(-k_frag * t))]

        Parameters:
        -----------
        t : float
            Time in months
        beta_bio : float
            Maximum yield penalty
        k_frag : float
            Fragmentation rate (month^-1)

        Returns:
        --------
        float : yield fraction relative to BAU
        """
        return 1.0 - beta_bio * (1.0 - np.exp(-k_frag * t))

    # ===== Groundwater Leaching Projections (SM S11.1, Table) =====

    def project_groundwater(self, 
                           base_concentration: float,
                           growth_rate: float,
                           scenario_reduction: Dict[str, float]) -> Dict:
        """
        Project groundwater phthalate concentrations to 2050.

        Parameters:
        -----------
        base_concentration : float
            Base concentration (ug/L)
        growth_rate : float
            Annual growth rate
        scenario_reduction : dict
            {scenario_name: fractional reduction}

        Returns:
        --------
        dict : projected concentrations by scenario and year
        """
        projections = {}

        for scenario, reduction in scenario_reduction.items():
            concentrations = []
            for year in self.years:
                years_elapsed = year - self.base_year

                # Exponential growth with scenario reduction
                conc = base_concentration * (1 + growth_rate) ** years_elapsed
                conc *= (1 - reduction)

                concentrations.append(conc)

            projections[scenario] = {
                'years': self.years,
                'concentrations': np.array(concentrations),
                'median_2050': concentrations[-1]
            }

        return projections
