"""
Monte Carlo Uncertainty Propagation Module
=============================================
Latin Hypercube Sampling for predictive uncertainty quantification.

Equations implemented:
  SM S4.2: LHS parameter distributions and convergence verification
  SM S7.2: Gelman-Rubin convergence diagnostic

Key features:
  - Truncated distributions for bounded parameters
  - Convergence monitoring via CI stability
  - Parallel execution support
"""

import numpy as np
from scipy.stats import qmc, truncnorm, lognorm, norm
from scipy.stats import shapiro
from typing import Dict, Callable, Tuple, Optional, List
from dataclasses import dataclass
from concurrent.futures import ProcessPoolExecutor
import warnings


@dataclass
class DistributionConfig:
    """Configuration for parameter distributions (Table S4.2)"""
    distribution: str  # 'log-normal', 'normal', 'truncated-normal'
    mean: float
    std: float
    lower: Optional[float] = None
    upper: Optional[float] = None


class MonteCarloPropagation:
    """
    Monte Carlo uncertainty propagation using Latin Hypercube Sampling.

    Implements parameter uncertainty distributions from Table S4.2
    and convergence verification protocols.
    """

    def __init__(self, n_samples: int = 10000, n_chains: int = 4,
                 seed: int = 42):
        """
        Initialize Monte Carlo propagation.

        Parameters:
        -----------
        n_samples : int
            Total number of LHS samples
        n_chains : int
            Number of independent chains for Gelman-Rubin
        seed : int
            Random seed
        """
        self.n_samples = n_samples
        self.n_chains = n_chains
        self.seed = seed
        self.samples_per_chain = n_samples // n_chains

    # ===== Distribution Sampling =====

    @staticmethod
    def sample_truncated_normal(mean: float, std: float,
                                lower: float, upper: float,
                                n: int) -> np.ndarray:
        """
        Sample from truncated normal distribution.

        Parameters:
        -----------
        mean, std : float
            Distribution parameters
        lower, upper : float
            Truncation bounds
        n : int
            Number of samples

        Returns:
        --------
        array : n samples
        """
        a = (lower - mean) / std
        b = (upper - mean) / std
        return truncnorm.rvs(a, b, loc=mean, scale=std, size=n)

    @staticmethod
    def sample_log_normal(mean: float, sigma_frac: float,
                         lower: Optional[float] = None,
                         upper: Optional[float] = None,
                         n: int = 1) -> np.ndarray:
        """
        Sample from log-normal distribution.

        For log-normal with mean mu and std sigma:
        underlying normal has mu_ln = ln(mu^2 / sqrt(mu^2 + sigma^2))
        and sigma_ln = sqrt(ln(1 + (sigma/mu)^2))

        Parameters:
        -----------
        mean : float
            Mean of log-normal distribution
        sigma_frac : float
            Standard deviation as fraction of mean (e.g., 0.3 for 30%)
        lower, upper : float, optional
            Truncation bounds
        n : int
            Number of samples

        Returns:
        --------
        array : n samples
        """
        sigma = mean * sigma_frac

        # Convert to log-normal parameters
        sigma_ln = np.sqrt(np.log(1 + (sigma / mean)**2))
        mu_ln = np.log(mean**2 / np.sqrt(mean**2 + sigma**2))

        samples = lognorm.rvs(s=sigma_ln, scale=np.exp(mu_ln), size=n)

        if lower is not None:
            samples = np.maximum(samples, lower)
        if upper is not None:
            samples = np.minimum(samples, upper)

        return samples

    def generate_lhs_samples(self, param_configs: Dict[str, DistributionConfig],
                            n: Optional[int] = None) -> Dict[str, np.ndarray]:
        """
        Generate Latin Hypercube Samples for all parameters.

        Parameters:
        -----------
        param_configs : dict
            {param_name: DistributionConfig}
        n : int, optional
            Number of samples (uses self.n_samples if None)

        Returns:
        --------
        dict : {param_name: samples_array}
        """
        if n is None:
            n = self.n_samples

        k = len(param_configs)
        param_names = list(param_configs.keys())

        # Generate LHS in unit hypercube
        sampler = qmc.LatinHypercube(d=k, seed=self.seed)
        unit_samples = sampler.random(n=n)

        # Transform to parameter distributions
        samples = {}
        for i, name in enumerate(param_names):
            config = param_configs[name]
            u = unit_samples[:, i]

            if config.distribution == 'log-normal':
                # Use inverse CDF of log-normal
                sigma = config.mean * config.std
                sigma_ln = np.sqrt(np.log(1 + (sigma / config.mean)**2))
                mu_ln = np.log(config.mean**2 / np.sqrt(config.mean**2 + sigma**2))
                samples[name] = lognorm.ppf(u, s=sigma_ln, scale=np.exp(mu_ln))

            elif config.distribution == 'normal':
                samples[name] = norm.ppf(u, loc=config.mean, scale=config.std)

            elif config.distribution == 'truncated-normal':
                a = (config.lower - config.mean) / config.std
                b = (config.upper - config.mean) / config.std
                samples[name] = truncnorm.ppf(u, a, b, 
                                              loc=config.mean, 
                                              scale=config.std)
            else:
                raise ValueError(f"Unknown distribution: {config.distribution}")

            # Apply bounds
            if config.lower is not None:
                samples[name] = np.maximum(samples[name], config.lower)
            if config.upper is not None:
                samples[name] = np.minimum(samples[name], config.upper)

        return samples

    # ===== Monte Carlo Propagation =====

    def propagate(self, model: Callable,
                 param_configs: Dict[str, DistributionConfig],
                 n: Optional[int] = None,
                 parallel: bool = True,
                 n_cores: int = -1) -> Dict:
        """
        Propagate parameter uncertainties through model.

        Parameters:
        -----------
        model : callable
            Function y = model(params_dict) returning array
        param_configs : dict
            Parameter distribution configurations
        n : int, optional
            Number of samples
        parallel : bool
            Use parallel execution
        n_cores : int
            Number of cores (-1 = all available)

        Returns:
        --------
        dict : {
            'samples': parameter samples,
            'outputs': model outputs,
            'statistics': summary statistics,
            'percentiles': percentile values
        }
        """
        samples = self.generate_lhs_samples(param_configs, n)
        n_samples = len(list(samples.values())[0])

        # Evaluate model for all samples
        if parallel and n_samples > 100:
            outputs = self._parallel_evaluate(model, samples, n_cores)
        else:
            outputs = self._serial_evaluate(model, samples)

        outputs = np.array(outputs)

        # Compute statistics
        statistics = self._compute_statistics(outputs)

        return {
            'samples': samples,
            'outputs': outputs,
            'statistics': statistics,
            'percentiles': {
                '2.5': np.percentile(outputs, 2.5, axis=0),
                '50': np.median(outputs, axis=0),
                '97.5': np.percentile(outputs, 97.5, axis=0)
            }
        }

    def _serial_evaluate(self, model: Callable, 
                        samples: Dict[str, np.ndarray]) -> List:
        """Serial model evaluation."""
        n = len(list(samples.values())[0])
        outputs = []

        for i in range(n):
            params = {name: samples[name][i] for name in samples}
            outputs.append(model(params))

        return outputs

    def _parallel_evaluate(self, model: Callable,
                          samples: Dict[str, np.ndarray],
                          n_cores: int) -> List:
        """Parallel model evaluation using ProcessPoolExecutor."""
        n = len(list(samples.values())[0])

        # Prepare parameter dictionaries
        param_list = []
        for i in range(n):
            params = {name: samples[name][i] for name in samples}
            param_list.append(params)

        with ProcessPoolExecutor(max_workers=n_cores if n_cores > 0 else None) as executor:
            outputs = list(executor.map(model, param_list))

        return outputs

    def _compute_statistics(self, outputs: np.ndarray) -> Dict:
        """Compute summary statistics."""
        if outputs.ndim == 1:
            outputs = outputs.reshape(-1, 1)

        n_outputs = outputs.shape[1]

        stats = {
            'mean': np.mean(outputs, axis=0),
            'std': np.std(outputs, axis=0),
            'median': np.median(outputs, axis=0),
            'min': np.min(outputs, axis=0),
            'max': np.max(outputs, axis=0),
            'cv': np.std(outputs, axis=0) / np.mean(outputs, axis=0)
        }

        return stats

    # ===== Convergence Verification (SM S4.2, S7.2) =====

    def verify_convergence(self, model: Callable,
                          param_configs: Dict[str, DistributionConfig],
                          batch_sizes: List[int] = None,
                          tolerance: float = 0.02) -> Dict:
        """
        Verify Monte Carlo convergence via CI stability (SM S4.2).

        Sequential batches evaluated; convergence when relative change
        in 95% CI bounds < tolerance over 3 consecutive batches.

        Parameters:
        -----------
        model : callable
            Model function
        param_configs : dict
            Parameter distributions
        batch_sizes : list, optional
            Batch sizes to test (default: [1000, 2000, 5000, 8000, 10000])
        tolerance : float
            Relative change tolerance for convergence

        Returns:
        --------
        dict : convergence results
        """
        if batch_sizes is None:
            batch_sizes = [1000, 2000, 5000, 8000, 10000]

        results = {}
        prev_ci = None
        converged = False
        converged_at = None

        for n in batch_sizes:
            samples = self.generate_lhs_samples(param_configs, n)
            outputs = self._serial_evaluate(model, samples)
            outputs = np.array(outputs)

            ci_low = np.percentile(outputs, 2.5)
            ci_high = np.percentile(outputs, 97.5)
            median = np.median(outputs)

            results[n] = {
                'ci_low': ci_low,
                'ci_high': ci_high,
                'median': median,
                'std': np.std(outputs)
            }

            if prev_ci is not None:
                change_low = abs(ci_low - prev_ci[0]) / abs(prev_ci[0])
                change_high = abs(ci_high - prev_ci[1]) / abs(prev_ci[1])

                results[n]['change_low'] = change_low
                results[n]['change_high'] = change_high

                if change_low < tolerance and change_high < tolerance:
                    if converged_at is None:
                        converged_at = n
                    converged = True

            prev_ci = (ci_low, ci_high)

        results['converged'] = converged
        results['converged_at'] = converged_at

        return results

    def gelman_rubin_diagnostic(self, model: Callable,
                               param_configs: Dict[str, DistributionConfig],
                               n_per_chain: Optional[int] = None) -> Dict:
        """
        Gelman-Rubin convergence diagnostic (SM S7.2, Eq. S7.6).

        R_hat = sqrt[(n-1)/n * W + 1/n * B] / W

        Parameters:
        -----------
        model : callable
            Model function
        param_configs : dict
            Parameter distributions
        n_per_chain : int, optional
            Samples per chain

        Returns:
        --------
        dict : R_hat values and convergence status
        """
        if n_per_chain is None:
            n_per_chain = self.samples_per_chain

        m = self.n_chains

        # Run m independent chains
        chain_outputs = []
        for i in range(m):
            seed = self.seed + i * 1000
            sampler = qmc.LatinHypercube(d=len(param_configs), seed=seed)

            samples = self.generate_lhs_samples(param_configs, n_per_chain)
            outputs = self._serial_evaluate(model, samples)
            chain_outputs.append(np.array(outputs))

        # Compute R_hat for each output dimension
        chain_outputs = np.array(chain_outputs)  # (m, n_per_chain, n_outputs)

        if chain_outputs.ndim == 2:
            chain_outputs = chain_outputs.reshape(m, n_per_chain, 1)

        n_outputs = chain_outputs.shape[2]
        R_hat = np.zeros(n_outputs)

        for j in range(n_outputs):
            # Within-chain variance
            W = np.mean([np.var(chain_outputs[i, :, j], ddof=1) 
                        for i in range(m)])

            # Between-chain variance
            chain_means = np.array([np.mean(chain_outputs[i, :, j]) 
                                   for i in range(m)])
            B = n_per_chain * np.var(chain_means, ddof=1)

            # Pooled variance estimate
            var_hat = (n_per_chain - 1) / n_per_chain * W + B / n_per_chain

            # R_hat
            R_hat[j] = np.sqrt(var_hat / W)

        return {
            'R_hat': R_hat,
            'converged': np.all(R_hat < 1.1),
            'well_converged': np.all(R_hat < 1.05),
            'n_chains': m,
            'n_per_chain': n_per_chain
        }

    # ===== Variance Decomposition =====

    def variance_decomposition(self, outputs: np.ndarray,
                              param_samples: Dict[str, np.ndarray],
                              param_groups: Dict[str, List[str]]) -> Dict:
        """
        Decompose output variance by parameter group (Fig. 5c).

        Parameters:
        -----------
        outputs : array
            Model outputs
        param_samples : dict
            Parameter samples
        param_groups : dict
            {group_name: [param_names]}

        Returns:
        --------
        dict : variance contribution by group
        """
        total_var = np.var(outputs)

        contributions = {}
        for group_name, params in param_groups.items():
            # Compute variance explained by group using correlation
            group_variance = 0
            for param in params:
                if param in param_samples:
                    corr = np.corrcoef(param_samples[param], outputs)[0, 1]
                    group_variance += corr**2 * total_var

            contributions[group_name] = {
                'variance': group_variance,
                'fraction': group_variance / total_var * 100
            }

        return contributions
