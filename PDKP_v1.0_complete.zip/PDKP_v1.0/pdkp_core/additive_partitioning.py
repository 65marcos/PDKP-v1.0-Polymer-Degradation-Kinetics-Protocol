"""
Module II: Additive Partitioning
===================================
Links polymer degradation state to additive diffusion coefficients
and equilibrium partition coefficients between polymer, soil solution,
and organic matter.

Equations implemented:
  Eq. 7: dM_add,poly/dt = -k_release * M_add,poly * D(t)^delta
  Eq. 8: C_OM = K_d * C_w
  Eq. 9: K_d = f_OC * K_OC * (1 + lambda_OM * [OM])

SM S2.2: Non-linear sorption enhancement at high organic matter
SM S2.3: Additive source term R_source(z,t)
SM S3.3: pp-LFER predictions for missing K_OC values
SM S4.3: WLF parameter sensitivity for D_poly
"""

import numpy as np
from scipy.integrate import solve_ivp
from dataclasses import dataclass
from typing import Dict, Optional, Tuple


@dataclass
class AdditiveParams:
    """Additive physicochemical properties (Table 2, main text)"""
    name: str
    MW: float           # g/mol, molecular weight
    S_w: float          # mg/L, aqueous solubility
    log_K_OW: float     # octanol-water partition coefficient
    log_K_OC: float     # L/kg, organic carbon-water partition coefficient
    D_poly: float       # m^2/s, polymer diffusion coefficient
    EU_limit: float     # mg/kg, EU REACH limit
    US_limit: float     # mg/kg, US EPA limit
    pKa: Optional[float] = None  # acid dissociation constant

    @property
    def K_OC(self) -> float:
        """K_OC in L/kg (linear scale)"""
        return 10 ** self.log_K_OC


# Additive database (Table 2)
ADDITIVE_DATABASE = {
    'DEHP': AdditiveParams(
        name='DEHP', MW=390.6, S_w=0.003, log_K_OW=7.73,
        log_K_OC=4.8, D_poly=1.2e-14,
        EU_limit=0.8, US_limit=1.2, pKa=None
    ),
    'Bisphenol_A': AdditiveParams(
        name='Bisphenol A', MW=228.3, S_w=300.0, log_K_OW=3.32,
        log_K_OC=2.5, D_poly=8.5e-13,
        EU_limit=1.5, US_limit=2.0, pKa=9.8
    ),
    'UV-328': AdditiveParams(
        name='UV-328', MW=351.5, S_w=0.05, log_K_OW=6.08,
        log_K_OC=4.2, D_poly=3.1e-14,
        EU_limit=2.3, US_limit=3.0, pKa=None
    ),
    'TCEP': AdditiveParams(
        name='TCEP', MW=285.5, S_w=1200.0, log_K_OW=1.44,
        log_K_OC=1.8, D_poly=2.8e-12,
        EU_limit=5.0, US_limit=6.0, pKa=None
    ),
    'Nonylphenol': AdditiveParams(
        name='Nonylphenol', MW=220.4, S_w=5.0, log_K_OW=5.76,
        log_K_OC=4.0, D_poly=5.5e-13,
        EU_limit=1.0, US_limit=1.5, pKa=10.5
    ),
}


# pp-LFER coefficients (SM S3.3, Endo et al. 2009)
PP_LFER_COEFFS = {
    'e': 0.50,   # excess molar refraction
    's': -0.64,  # dipolarity/polarizability
    'a': -0.80,  # H-bond acidity
    'b': -1.10,  # H-bond basicity
    'v': 0.92,   # McGowan volume
    'c': 0.12,   # intercept
}


@dataclass
class SoilProps:
    """Soil properties for partitioning calculations"""
    f_OC: float       # fraction organic carbon
    OM_percent: float # organic matter (%)
    clay_percent: float  # clay content (%)
    bulk_density: float  # g/cm^3
    pH: float         # soil pH
    CEC: float = 12.5  # cmol/kg, cation exchange capacity
    Fe_oxalate: float = 0.015  # fraction amorphous Fe oxides


class AdditivePartitioning:
    """
    Module II: Additive Partitioning

    Computes additive release kinetics and partitioning between
    polymer, soil solution, and organic matter phases.
    """

    def __init__(self, additive_name: str, polymer_type: str,
                 additive_params: Optional[AdditiveParams] = None):
        """
        Initialize additive partitioning module.

        Parameters:
        -----------
        additive_name : str
            One of 'DEHP', 'Bisphenol_A', 'UV-328', 'TCEP', 'Nonylphenol'
        polymer_type : str
            One of 'PE', 'PP', 'PET', 'PLA', 'PBAT'
        additive_params : AdditiveParams, optional
            Custom additive parameters
        """
        if additive_params is None:
            if additive_name not in ADDITIVE_DATABASE:
                raise ValueError(f"Unknown additive: {additive_name}")
            self.additive = ADDITIVE_DATABASE[additive_name]
        else:
            self.additive = additive_params

        self.additive_name = additive_name
        self.polymer_type = polymer_type

        # Lambda parameter for non-linear OM sorption (SM S2.2)
        self.lambda_OM = 0.5  # L/kg, from Freundlich fitting

    # ===== pp-LFER Method (SM S3.3, Eq. S3.1) =====

    @staticmethod
    def pp_lfer_predict(abraham_descriptors: Dict[str, float]) -> float:
        """
        Predict log K_OC using polyparameter linear free energy relationship.

        log K_OC = e*E + s*S + a*A + b*B + v*V + c

        Parameters:
        -----------
        abraham_descriptors : dict
            {'E': ..., 'S': ..., 'A': ..., 'B': ..., 'V': ...}

        Returns:
        --------
        float : predicted log K_OC
        """
        coeffs = PP_LFER_COEFFS
        log_K_OC = (coeffs['e'] * abraham_descriptors['E'] +
                    coeffs['s'] * abraham_descriptors['S'] +
                    coeffs['a'] * abraham_descriptors['A'] +
                    coeffs['b'] * abraham_descriptors['B'] +
                    coeffs['v'] * abraham_descriptors['V'] +
                    coeffs['c'])
        return log_K_OC

    # ===== Partition Coefficients (Eq. 8-9) =====

    def compute_Kd(self, soil: SoilProps, 
                   use_nonlinear_OM: bool = True,
                   use_composite: bool = False) -> float:
        """
        Compute soil-water distribution coefficient K_d (Eq. 9).

        K_d = f_OC * K_OC * (1 + lambda_OM * [OM])   [standard]

        With composite model (SM S12.6):
        K_d = f_OC * K_OC + f_clay * K_clay + gamma_Fe * K_Fe

        Parameters:
        -----------
        soil : SoilProps
            Soil properties
        use_nonlinear_OM : bool
            Include non-linear OM enhancement term
        use_composite : bool
            Use composite model with clay and Fe-oxyhydroxides

        Returns:
        --------
        float : K_d in L/kg
        """
        K_OC = self.additive.K_OC
        f_OC = soil.f_OC

        if use_composite:
            # Composite model (SM S12.6, Eq. S12.23)
            f_clay = soil.clay_percent / 100.0
            gamma_Fe = soil.Fe_oxalate

            # Clay-specific coefficients (Table S12.3)
            K_clay = self._get_K_clay()
            K_Fe = self._get_K_Fe(soil.pH)

            K_d = f_OC * K_OC + f_clay * K_clay + gamma_Fe * K_Fe
        else:
            # Standard model (Eq. 9)
            K_d = f_OC * K_OC

            if use_nonlinear_OM:
                # Non-linear sorption enhancement (SM S2.2)
                OM_fraction = soil.OM_percent / 100.0
                enhancement = 1.0 + self.lambda_OM * OM_fraction
                K_d *= enhancement

        return K_d

    def _get_K_clay(self) -> float:
        """Get clay-specific partition coefficient (Table S12.3)"""
        # Average values across clay minerals
        clay_K = {
            'DEHP': 22, 'Bisphenol_A': 5, 'UV-328': 31,
            'TCEP': 3, 'Nonylphenol': 15
        }
        return clay_K.get(self.additive_name, 10)

    def _get_K_Fe(self, pH: float) -> float:
        """Get Fe-oxyhydroxide partition coefficient (Table S12.4)"""
        # Neutral species
        K_Fe_neutral = {
            'DEHP': 2.5, 'Bisphenol_A': 0.5, 'UV-328': 3.0,
            'TCEP': 0.3, 'Nonylphenol': 1.0
        }

        base = K_Fe_neutral.get(self.additive_name, 1.0)

        # Enhanced for ionized species at high pH
        if self.additive.pKa is not None:
            if pH > self.additive.pKa + 0.5:
                base *= 5.0  # anion complexation

        return base

    # ===== pH-Dependent Partitioning (SM S12.3) =====

    def compute_pH_dependent_Kd(self, soil: SoilProps) -> float:
        """
        Compute pH-dependent apparent partition coefficient (SM S12.3).

        For ionizable additives:
        K_OC,app = K_OC,neutral * f_neutral + K_OC,ion * (1 - f_neutral)

        Parameters:
        -----------
        soil : SoilProps
            Soil properties including pH

        Returns:
        --------
        float : apparent K_d in L/kg
        """
        if self.additive.pKa is None:
            return self.compute_Kd(soil)

        pKa = self.additive.pKa
        pH = soil.pH

        # Fraction of neutral species
        if self.additive_name in ['Bisphenol_A', 'Nonylphenol']:
            # Acidic: f_neutral = 1 / (1 + 10^(pH - pKa))
            f_neutral = 1.0 / (1.0 + 10 ** (pH - pKa))
        else:
            # Basic: f_neutral = 1 / (1 + 10^(pKa - pH))
            f_neutral = 1.0 / (1.0 + 10 ** (pKa - pH))

        K_OC_neutral = self.additive.K_OC
        K_OC_ion = K_OC_neutral * 0.05  # ~5% of neutral (SM S12.3)

        K_OC_app = K_OC_neutral * f_neutral + K_OC_ion * (1 - f_neutral)

        # Apply to standard K_d calculation
        f_OC = soil.f_OC
        K_d = f_OC * K_OC_app * (1 + self.lambda_OM * soil.OM_percent / 100.0)

        return K_d

    # ===== Additive Release Kinetics (Eq. 7) =====

    def compute_release_rate(self, k_release: float, D: float, 
                            delta: float) -> float:
        """
        Compute degradation-dependent release rate (Eq. 7).

        dM_add,poly/dt = -k_release * M_add,poly * D(t)^delta

        Parameters:
        -----------
        k_release : float
            Intrinsic release rate constant (day^-1)
        D : float
            Degree of degradation [0, 1]
        delta : float
            Degradation-dependence exponent

        Returns:
        --------
        float : release rate factor (day^-1)
        """
        return k_release * (D ** delta)

    def solve_release(self, t_span: Tuple[float, float],
                     D_t: callable,
                     k_release: float,
                     delta: float,
                     M_add0: float,
                     t_eval: Optional[np.ndarray] = None) -> solve_ivp:
        """
        Solve additive release from polymer over time.

        Parameters:
        -----------
        t_span : tuple
            (t_start, t_end) in days
        D_t : callable
            Function D(t) returning degree of degradation
        k_release : float
            Intrinsic release rate (day^-1)
        delta : float
            Degradation-dependence exponent
        M_add0 : float
            Initial additive mass in polymer (mg/kg soil)
        t_eval : array, optional
            Time points for output

        Returns:
        --------
        OdeResult : SciPy solve_ivp result
        """
        def ode(t, y):
            D = D_t(t)
            rate = self.compute_release_rate(k_release, D, delta)
            return -rate * y[0]

        sol = solve_ivp(ode, t_span, [M_add0], method='BDF',
                       t_eval=t_eval, rtol=1e-6, atol=1e-9)
        return sol

    # ===== Source Term R_source(z,t) (SM S2.3, Eq. S2.2) =====

    def compute_source_term(self, z: float, t: float,
                         M_add_poly: float, D: float,
                         k_release: float, delta: float,
                         soil: SoilProps,
                         z_MP: float = 0.0,  # burial depth
                         incorporation_depth: float = 5.0) -> float:
        """
        Compute additive source term for soil transport (Eq. S2.2).

        R_source(z,t) = (rho_b/theta) * k_release * M_add,poly(z,t) * D(t)^delta * delta(z - z_MP)

        Parameters:
        -----------
        z : float
            Soil depth (cm)
        t : float
            Time (days)
        M_add_poly : float
            Additive mass in polymer phase (mg/kg soil)
        D : float
            Degree of degradation
        k_release : float
            Release rate constant (day^-1)
        delta : float
            Degradation-dependence exponent
        soil : SoilProps
            Soil properties
        z_MP : float
            Microplastic burial depth (cm)
        incorporation_depth : float
            Depth over which MPs are distributed (cm)

        Returns:
        --------
        float : R_source in mg/L/day
        """
        rho_b = soil.bulk_density * 1000  # kg/m^3
        theta = 0.20  # assume typical volumetric water content

        # Release rate from polymer
        release_rate = k_release * M_add_poly * (D ** delta)

        # Spatial distribution (uniform over incorporation depth)
        if 0 <= z <= incorporation_depth:
            spatial_factor = 1.0 / incorporation_depth  # per cm
        else:
            spatial_factor = 0.0

        R_source = (rho_b / theta) * release_rate * spatial_factor * 1e-6  # convert units

        return R_source

    # ===== Temperature-Dependent Polymer Diffusion (WLF) =====

    def compute_Dpoly_temperature(self, T: float, polymer_deg_module) -> float:
        """
        Compute temperature-dependent polymer diffusion coefficient
        using WLF equation (SM S4.3).

        Parameters:
        -----------
        T : float
            Temperature (K)
        polymer_deg_module : PolymerDegradation
            Polymer degradation module for WLF parameters

        Returns:
        --------
        float : D_poly at temperature T (m^2/s)
        """
        D_ratio = polymer_deg_module.wlf_diffusion(T)
        return self.additive.D_poly * D_ratio

    # ===== Salinity Correction (SM S12.6.6) =====

    def salinity_correction(self, K_OC: float, ionic_strength: float) -> float:
        """
        Apply salinity correction to K_OC (SM S12.6.6).

        log K_OC,corr = log K_OC - 0.15 * log(I / I_ref)

        Parameters:
        -----------
        K_OC : float
            Organic carbon partition coefficient (L/kg)
        ionic_strength : float
            Ionic strength (M)

        Returns:
        --------
        float : corrected K_OC
        """
        I_ref = 0.001  # M, reference ionic strength
        log_KOC = np.log10(K_OC)
        log_KOC_corr = log_KOC - 0.15 * np.log10(ionic_strength / I_ref)
        return 10 ** log_KOC_corr
