"""
PDKP v1.0 - Polymer Degradation Kinetics for Plastics
Setup script for package installation.
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="pdkp",
    version="1.0.0",
    author="Marcos Fernandes de Oliveira",
    author_email="marcos.fernandes1@estudante.ifgoiano.edu.br",
    description="Process-Based Modeling of Microplastic-Associated Additive Dynamics in Agricultural Soils",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/65marcos/soil-microplastics",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Environmental Science",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.10",
    install_requires=requirements,
    extras_require={
        "dev": ["pytest>=6.2.0", "pytest-cov>=2.12.0", "sphinx>=4.0.0"],
    },
    include_package_data=True,
    package_data={
        "pdkp_core": ["../data/*.json", "../data/*.csv"],
    },
)
