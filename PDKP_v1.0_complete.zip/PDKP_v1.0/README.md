# PDKP v1.0 - Polymer Degradation Kinetics for Plastics

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.20680510.svg)](https://doi.org/10.5281/zenodo.20680510)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**Process-Based Modeling of Microplastic-Associated Additive Dynamics in Agricultural Soils**

A mechanistic framework for polymer degradation, additive partitioning, and soil transport in agricultural soils.

---

## Overview

The PDKP (Polymer-Degradation-Kinetics-for-Plastics) model is a process-based framework that couples polymer degradation, additive partitioning, and soil transport to predict chemical migration under realistic field conditions. Parameterized for polyethylene (PE), polypropylene (PP), polyethylene terephthalate (PET), and biodegradable alternatives (PLA, PBAT).

### Key Features

- **Module I: Polymer Degradation** — Tracks molecular weight, crystallinity, and surface area evolution
- **Module II: Additive Partitioning** — Links degradation state to additive diffusion and partitioning
- **Module III: Soil Transport** — Simulates advection-dispersion with sorption and biodegradation
- **Sensitivity Analysis** — Variance-based Sobol indices and Morris screening
- **Uncertainty Quantification** — Latin Hypercube Sampling with convergence verification
- **Scenario Projections** — CMIP6 climate downscaling and management alternatives
- **Error Documentation** — Living error log and verification protocols

### Manuscript

Fernandes de Oliveira, M., de Souza Castro, C.F., Albuquerque Andrade, R.D., da Silva Oliveira, D.M. (2026). Process-Based Modeling of Microplastic-Associated Additive Dynamics in Agricultural Soils: A Mechanistic Framework for Release Kinetics, Sensitivity Analysis, and Predictive Scenarios. *Journal of Environmental Quality* (submitted).

---

## Installation

### Requirements

- Python 3.10+
- NumPy ≥ 1.21
- SciPy ≥ 1.7
- Pandas ≥ 1.3
- Matplotlib ≥ 3.4

### Install from source

```bash
git clone https://github.com/65marcos/soil-microplastics.git
cd soil-microplastics
pip install -e .
```

### Install dependencies

```bash
pip install -r requirements.txt
```

---

## Quick Start

### 1. Polymer Degradation Simulation

```python
from pdkp_core import PolymerDegradation
import numpy as np

# Initialize PE degradation module
deg = PolymerDegradation('PE')

# Environmental conditions
env = {
    'I_UV': 650,      # W/m²
    'T': 298.15,      # K (25°C)
    'theta': 0.20,    # m³/m³
    'sigma_soil': 100e3  # Pa
}

# Run 5-year simulation
days = np.linspace(0, 365*5, 100)
results = deg.simulate(days, env)

# Access results
print(f"M_n reduction: {(1 - results['M_n'][-1]/results['M_n'][0])*100:.1f}%")
print(f"Final crystallinity: {results['crystallinity'][-1]:.1f}%")
```

### 2. Additive Partitioning

```python
from pdkp_core import AdditivePartitioning
from pdkp_core.additive_partitioning import SoilProps

# Initialize DEHP partitioning
part = AdditivePartitioning('DEHP', 'PE')

# Soil properties
soil = SoilProps(
    f_OC=0.012, OM_percent=1.2, clay_percent=18,
    bulk_density=1.35, pH=8.3
)

# Compute distribution coefficient
K_d = part.compute_Kd(soil)
print(f"K_d = {K_d:.1f} L/kg")
```

### 3. Sensitivity Analysis

```python
from pdkp_core import SensitivityAnalysis

# Define parameter bounds
param_bounds = {
    'I_UV': (400, 800),
    'OM': (0.5, 5.0),
    'T': (278, 308),
    'k_deg': (1e-6, 1e-3),
}

# Run Sobol analysis
sa = SensitivityAnalysis()
results = sa.compute_sobol_indices(model, param_bounds)

# Print top drivers
for i in np.argsort(-results['S_Ti'])[:3]:
    print(f"{results['param_names'][i]}: S_Ti = {results['S_Ti'][i]:.3f}")
```

### 4. Monte Carlo Uncertainty

```python
from pdkp_core import MonteCarloPropagation
from pdkp_core.monte_carlo import DistributionConfig

# Define parameter distributions
param_configs = {
    'k_deg': DistributionConfig('log-normal', 2.1e-5, 0.3),
    'K_OC': DistributionConfig('log-normal', 63096, 0.5),
    'E_a': DistributionConfig('normal', 42.0, 5.0),
}

# Propagate uncertainty
mc = MonteCarloPropagation(n_samples=10000)
results = mc.propagate(model, param_configs)

print(f"Median: {results['percentiles']['50']:.2f}")
print(f"95% CI: [{results['percentiles']['2.5']:.2f}, {results['percentiles']['97.5']:.2f}]")
```

---

## Repository Structure

```
PDKP_v1.0/
├── pdkp_core/                  # Core model modules
│   ├── __init__.py
│   ├── polymer_degradation.py  # Module I
│   ├── additive_partitioning.py # Module II
│   ├── soil_transport.py       # Module III
│   ├── sensitivity_analysis.py # Sobol & Morris
│   ├── monte_carlo.py          # LHS uncertainty
│   ├── validation.py           # Metrics & benchmarking
│   ├── scenario_projections.py # Future scenarios
│   ├── error_analysis.py       # Error documentation
│   └── extensions.py           # Future extensions
├── data/                       # Input templates
│   ├── site_parameters.csv
│   ├── climate_forcing.csv
│   ├── management_scenarios.csv
│   ├── polymer_database.json
│   └── additive_database.json
├── notebooks/                  # Jupyter notebooks
│   ├── 01_validation.ipynb
│   ├── 02_sensitivity_analysis.ipynb
│   └── 03_monte_carlo.ipynb
├── tests/                      # Unit tests
│   ├── test_polymer_degradation.py
│   ├── test_additive_partitioning.py
│   └── test_validation.py
├── scripts/                    # Execution scripts
│   └── run_pdkp.py
├── docs/                       # Documentation
├── config.yaml                 # Master configuration
├── requirements.txt            # Dependencies
├── setup.py                    # Package setup
├── LICENSE                     # MIT License
└── README.md                   # This file
```

---

## Notebooks

| Notebook | Content |
|----------|---------|
| `01_validation.ipynb` | Xinjiang field validation, Fig. 2, Table 4 |
| `02_sensitivity_analysis.ipynb` | Sobol & Morris analysis, Fig. 4 |
| `03_monte_carlo.ipynb` | Uncertainty propagation, Fig. 5 |

---

## Validation

The model was validated against four-year field data from Xinjiang cotton fields (2018–2022):

| Variable | NSE | PBIAS | R² | Class |
|----------|-----|-------|-----|-------|
| MP mass | 0.72 | +5% | 0.78 | Good |
| Phthalate soil | 0.68 | −8% | 0.74 | Good |
| UV-328 soil | 0.65 | +3% | 0.71 | Good |

Transferability confirmed across North China Plain, Yangtze Delta, and Northeast China without recalibration.

---

## Citation

If you use PDKP in your research, please cite:

```bibtex
@software{pdkp_v1_0,
  author = {Fernandes de Oliveira, Marcos and de Souza Castro, Carlos Frederico and 
            Albuquerque Andrade, Rômulo Davi and da Silva Oliveira, Dener Márcio},
  title = {PDKP v1.0: Polymer Degradation Kinetics for Plastics},
  year = {2026},
  publisher = {Zenodo},
  doi = {10.5281/zenodo.20680510},
  url = {https://github.com/65marcos/soil-microplastics}
}
```

---

## License

This project is licensed under the MIT License - see [LICENSE](LICENSE) file for details.

---

## Contact

- **Corresponding author:** Marcos Fernandes de Oliveira (marcos.fernandes1@estudante.ifgoiano.edu.br)
- **Issues:** [GitHub Issues](https://github.com/65marcos/soil-microplastics/issues)
- **Repository:** https://github.com/65marcos/soil-microplastics

---

## Acknowledgments

This work was supported by the Federal Institute of Science, Technology, and Education of Goiás (IF Goiano) and the Federal University of Viçosa (UFV). Climate projections use CMIP6 SSP2-4.5 ensemble data.
