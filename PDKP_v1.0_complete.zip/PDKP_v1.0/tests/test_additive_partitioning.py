"""
Unit tests for Additive Partitioning Module (Module II).
"""

import numpy as np
import pytest
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from pdkp_core import AdditivePartitioning
from pdkp_core.additive_partitioning import ADDITIVE_DATABASE, SoilProps


class TestAdditivePartitioning:
    """Test suite for additive partitioning module."""

    def test_initialization(self):
        """Test additive database initialization."""
        for additive in ['DEHP', 'Bisphenol_A', 'UV-328', 'TCEP', 'Nonylphenol']:
            part = AdditivePartitioning(additive, 'PE')
            assert part.additive is not None

    def test_Kd_computation(self):
        """Test distribution coefficient (Eq. 9)."""
        part = AdditivePartitioning('DEHP', 'PE')

        soil = SoilProps(
            f_OC=0.012, OM_percent=1.2, clay_percent=18,
            bulk_density=1.35, pH=8.3
        )

        K_d = part.compute_Kd(soil)

        # K_d should be positive
        assert K_d > 0

        # With non-linear OM term
        K_d_nl = part.compute_Kd(soil, use_nonlinear_OM=True)
        assert K_d_nl > K_d  # Non-linear term enhances sorption

    def test_pH_dependence(self):
        """Test pH-dependent partitioning (SM S12.3)."""
        part = AdditivePartitioning('Bisphenol_A', 'PE')

        # At low pH (protonated), K_d should be higher
        Kd_low_pH = part.compute_pH_dependent_Kd(
            SoilProps(f_OC=0.012, OM_percent=1.2, clay_percent=18,
                     bulk_density=1.35, pH=5.0)
        )

        # At high pH (ionized), K_d should be lower
        Kd_high_pH = part.compute_pH_dependent_Kd(
            SoilProps(f_OC=0.012, OM_percent=1.2, clay_percent=18,
                     bulk_density=1.35, pH=10.0)
        )

        assert Kd_low_pH > Kd_high_pH

    def test_pp_lfer(self):
        """Test pp-LFER prediction (SM S3.3)."""
        descriptors = {
            'E': 1.08, 'S': 1.08, 'A': 0.00, 'B': 0.80, 'V': 2.65
        }

        log_K_OC = AdditivePartitioning.pp_lfer_predict(descriptors)

        # Should be reasonable for phthalate
        assert 4.0 < log_K_OC < 6.0

    def test_release_rate(self):
        """Test degradation-dependent release rate (Eq. 7)."""
        part = AdditivePartitioning('DEHP', 'PE')

        # At D=0, release rate should be 0
        rate_0 = part.compute_release_rate(0.01, 0.0, 1.2)
        assert rate_0 == 0.0

        # At D=1, release rate should be maximum
        rate_1 = part.compute_release_rate(0.01, 1.0, 1.2)
        assert rate_1 == 0.01

        # Intermediate D
        rate_mid = part.compute_release_rate(0.01, 0.5, 1.2)
        assert 0 < rate_mid < rate_1


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
