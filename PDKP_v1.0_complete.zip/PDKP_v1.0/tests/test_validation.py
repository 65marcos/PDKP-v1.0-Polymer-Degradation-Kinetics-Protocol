"""
Unit tests for Validation Metrics Module.
"""

import numpy as np
import pytest
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from pdkp_core import ValidationMetrics


class TestValidationMetrics:
    """Test suite for validation metrics."""

    def test_nse_perfect(self):
        """NSE = 1 for perfect prediction."""
        val = ValidationMetrics()
        obs = np.array([1, 2, 3, 4, 5])
        pred = obs.copy()

        nse = val.nash_sutcliffe(obs, pred)
        assert np.isclose(nse, 1.0)

    def test_nse_mean(self):
        """NSE = 0 for mean prediction."""
        val = ValidationMetrics()
        obs = np.array([1, 2, 3, 4, 5])
        pred = np.full_like(obs, np.mean(obs))

        nse = val.nash_sutcliffe(obs, pred)
        assert np.isclose(nse, 0.0, atol=0.01)

    def test_pbias_zero(self):
        """PBIAS = 0 for perfect prediction."""
        val = ValidationMetrics()
        obs = np.array([1, 2, 3, 4, 5])
        pred = obs.copy()

        pbias = val.percent_bias(obs, pred)
        assert np.isclose(pbias, 0.0)

    def test_pbias_positive(self):
        """Positive PBIAS for overprediction."""
        val = ValidationMetrics()
        obs = np.array([1, 2, 3, 4, 5])
        pred = obs * 1.2

        pbias = val.percent_bias(obs, pred)
        assert pbias > 0

    def test_performance_classification(self):
        """Test performance classification."""
        val = ValidationMetrics()

        # Good performance
        obs = np.array([1, 2, 3, 4, 5])
        pred = obs + np.random.normal(0, 0.1, len(obs))

        result = val.compute_all(obs, pred)
        assert result.performance_class in ['good', 'very_good', 'acceptable']

    def test_benchmarking(self):
        """Test model benchmarking."""
        val = ValidationMetrics()

        obs = np.array([1, 2, 3, 4, 5])
        predictions = {
            'PDKP': obs + np.random.normal(0, 0.1, len(obs)),
            'FODM': obs * 1.3,
            'HYDRUS': obs * 1.1
        }

        results = val.benchmark_models(obs, predictions)

        assert 'PDKP' in results
        assert 'FODM' in results
        assert 'HYDRUS' in results

        # PDKP should outperform others
        assert results['PDKP'].NSE > results['FODM'].NSE


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
