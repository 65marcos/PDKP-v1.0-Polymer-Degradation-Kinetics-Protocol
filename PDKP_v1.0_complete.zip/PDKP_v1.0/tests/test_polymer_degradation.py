"""
Unit tests for Polymer Degradation Module (Module I).

Tests correspond to verification checks V-001 through V-004 (SM S13.3).
"""

import numpy as np
import pytest
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from pdkp_core import PolymerDegradation
from pdkp_core.polymer_degradation import POLYMER_DATABASE, R_GAS, I_REF, T_REF


class TestPolymerDegradation:
    """Test suite for polymer degradation module."""

    def test_initialization(self):
        """Test polymer database initialization."""
        for polymer_type in ['PE', 'PP', 'PET', 'PLA', 'PBAT']:
            deg = PolymerDegradation(polymer_type)
            assert deg.params is not None
            assert deg.params.name == polymer_type

    def test_modification_factors(self):
        """Test environmental modification factors (Eq. 3-6)."""
        deg = PolymerDegradation('PE')

        # Test at reference conditions (all factors = 1)
        env_ref = {
            'I_UV': I_REF,
            'T': T_REF,
            'theta': 0.20,
            'sigma_soil': 100e3
        }

        factors = deg.compute_modification_factors(env_ref)
        assert np.isclose(factors['f_UV'], 1.0, rtol=0.01)
        assert np.isclose(factors['f_T'], 1.0, rtol=0.01)
        assert np.isclose(factors['f_moist'], 1.0, rtol=0.01)

        # Test UV factor scaling
        env_high_uv = env_ref.copy()
        env_high_uv['I_UV'] = 700
        f_uv_high = deg.f_UV(env_high_uv['I_UV'])
        assert f_uv_high > 1.0  # Higher UV -> higher factor

        # Test temperature factor (Arrhenius)
        env_hot = env_ref.copy()
        env_hot['T'] = 308.15  # 35°C
        f_t_hot = deg.f_T(env_hot['T'])
        assert f_t_hot > 1.0  # Higher T -> faster degradation

    def test_degree_of_degradation(self):
        """Test degree of degradation D(t) (Eq. 1)."""
        deg = PolymerDegradation('PE')

        # At t=0, D should be 0
        assert deg.degree_of_degradation(deg.params.M_n0) == 0.0

        # D should be in [0, 1]
        assert deg.degree_of_degradation(deg.params.M_n0 * 0.5) == 0.5
        assert deg.degree_of_degradation(deg.params.M_n0 * 0.1) == 0.9

    def test_crystallinity_biphasic(self):
        """Test biphasic crystallinity evolution (Section 3.1)."""
        deg = PolymerDegradation('PE')

        X_c0 = deg.params.crystallinity0

        # Phase 1: crystallinity should decrease
        X_c_early = deg.compute_crystallinity(0.05)
        assert X_c_early < X_c0

        # Phase 2: crystallinity should increase
        X_c_late = deg.compute_crystallinity(0.3)
        assert X_c_late > X_c_early

    def test_wlf_continuity(self):
        """Test WLF-Arrhenius continuity (V-002, E-003 correction)."""
        deg = PolymerDegradation('PE')

        T_g = deg.params.T_g
        C2 = deg.params.C2_wlf
        T_cross = T_g - C2

        # Test continuity at crossover
        delta = 0.1
        D_ratio_minus = deg.wlf_diffusion(T_cross - delta)
        D_ratio_plus = deg.wlf_diffusion(T_cross + delta)
        D_ratio_cross = deg.wlf_diffusion(T_cross)

        # Should be continuous within 1%
        assert abs(D_ratio_plus - D_ratio_cross) / D_ratio_cross < 0.01
        assert abs(D_ratio_minus - D_ratio_cross) / D_ratio_cross < 0.01

    def test_simulation_output(self):
        """Test full degradation simulation."""
        deg = PolymerDegradation('PE')

        days = np.linspace(0, 365*5, 100)
        env = {
            'I_UV': 650,
            'T': 298.15,
            'theta': 0.20,
            'sigma_soil': 100e3
        }

        results = deg.simulate(days, env)

        # Check outputs exist
        assert 'time' in results
        assert 'M_n' in results
        assert 'D' in results
        assert 'crystallinity' in results
        assert 'SA_V' in results

        # Check monotonicity: M_n should decrease
        assert np.all(np.diff(results['M_n']) <= 0)

        # D should increase
        assert np.all(np.diff(results['D']) >= 0)

        # D should be in [0, 1]
        assert np.all(results['D'] >= 0)
        assert np.all(results['D'] <= 1)

    def test_lambda_parameter(self):
        """Test lambda enhancement factor (SM S3.2)."""
        deg = PolymerDegradation('PE')

        # At reference conditions, lambda should be ~1
        lambda_ref = deg.compute_lambda(I_REF, 25, 0.20)
        assert lambda_ref > 0

        # Higher UV should increase lambda
        lambda_high = deg.compute_lambda(700, 25, 0.20)
        assert lambda_high > lambda_ref


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
